from malmoa_mcp.cli import main

main()
