"""MALMOA MCP adapter. Context data cannot authorize credential use."""
