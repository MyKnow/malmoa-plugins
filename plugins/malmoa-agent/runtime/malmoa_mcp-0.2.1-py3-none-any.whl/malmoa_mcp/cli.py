"""Interactive credential provisioning is separate from the MCP protocol process."""

import argparse
import getpass
import json
import logging
import os
import sys
from typing import Any, Never

from pydantic import SecretStr

from malmoa_mcp.credentials import (
    AdapterError,
    Profile,
    delete_profile,
    load_profile,
    save_profile,
)
from malmoa_mcp.gateway import Gateway
from malmoa_mcp.server import Adapter, create_server


class Parser(argparse.ArgumentParser):
    def error(self, message: str) -> Never:
        # An accidentally pasted credential must not be echoed by argparse.
        raise AdapterError("invalid_command_arguments")


def stdin_line(max_bytes: int) -> bytes:
    # No buffered read-ahead: a protocol message may follow a bootstrap frame
    # in the same pipe write. The SDK must receive every remaining byte.
    data = bytearray()
    while len(data) <= max_bytes:
        byte = os.read(0, 1)
        if byte == b"\n":
            return bytes(data).rstrip(b"\r")
        if not byte:
            raise AdapterError("bootstrap_input_incomplete")
        data.extend(byte)
    raise AdapterError("bootstrap_input_too_large")


def bootstrap_profile() -> Profile:
    try:
        frame = json.loads(stdin_line(8192))
        if (
            set(frame) != {"jsonrpc", "method", "params"}
            or frame["jsonrpc"] != "2.0"
            or frame["method"] != "malmoa/bootstrap"
        ):
            raise AdapterError("invalid_bootstrap_frame")
        return Profile.model_validate(frame["params"])
    except AdapterError:
        raise
    except Exception:
        raise AdapterError("invalid_bootstrap_frame") from None


def build_parser() -> Parser:
    parser = Parser(prog="malmoa-mcp")
    subcommands = parser.add_subparsers(dest="command", required=True, parser_class=Parser)
    configure = subcommands.add_parser("configure", help="Store a short Plugin credential securely")
    configure.add_argument("--profile", required=True)
    configure.add_argument("--gateway-origin", required=True)
    configure.add_argument("--client", choices=["codex", "claude"], required=True)
    configure.add_argument(
        "--destination", choices=["codex-model", "claude-model", "local-tool"], required=True
    )
    configure.add_argument("--stdin", action="store_true", help="Read credential line from a pipe")
    serve = subcommands.add_parser("serve", help="Run the MCP stdio server")
    serve.add_argument("--profile", required=True)
    serve.add_argument("--client", choices=["codex", "claude"], required=True)
    ephemeral = subcommands.add_parser("serve-stdin", help="Use one in-memory bootstrap frame")
    ephemeral.add_argument("--client", choices=["codex", "claude"], required=True)
    forget = subcommands.add_parser("forget", help="Remove a locally stored credential")
    forget.add_argument("--profile", required=True)
    for command in [
        "project-login",
        "project-configure",
        "project-serve",
        "project-hook",
        "project-sync",
        "project-status",
        "project-logout",
        "project-forget",
    ]:
        project = subcommands.add_parser(command, help="Scoped project continuity operation")
        project.add_argument("--profile", required=True)
        project.add_argument("--client", choices=["codex", "claude"], required=True)
        if command in {"project-login", "project-configure"}:
            project.add_argument("--gateway-origin", required=True)
            project.add_argument("--workspace", required=True)
        if command == "project-login":
            project.add_argument("--project-id", required=True)
            project.add_argument("--source-id", required=True)
            project.add_argument("--environment-name", required=True)
            project.add_argument("--allow-external-context", action="store_true")
        if command == "project-configure":
            project.add_argument("--stdin", action="store_true")
        if command in {"project-logout", "project-forget"}:
            project.add_argument("--discard-pending", action="store_true")
    for name in ("release-install", "update"):
        release = subcommands.add_parser(name, help="Install or update the public native plugin")
        release.add_argument("--server")
        release.add_argument("--client", choices=["codex", "claude", "both"])
        release.add_argument("--check", action="store_true")
    from malmoa_mcp.onboarding_cli import add_commands

    add_commands(subcommands)
    return parser


def execute(args: Any) -> None:
    if args.command in {"release-install", "update"}:
        from malmoa_mcp.releases import ReleaseError, execute_release

        try:
            print(json.dumps(execute_release(args)))
        except ReleaseError as error:
            raise AdapterError(str(error)) from None
        return
    if args.command in {"project-init", "project-import", "project-export", "project-doctor"}:
        from malmoa_mcp.onboarding_cli import execute_onboarding

        execute_onboarding(args)
        return
    if args.command.startswith("project-"):
        from malmoa_mcp.project_cli import execute_project

        execute_project(args, stdin_line)
        return
    if args.command == "forget":
        delete_profile(args.profile)
        print(
            "MALMOA credential removed locally; revoke the connection in MALMOA too.",
            file=sys.stderr,
        )
        return
    if args.command == "configure":
        if args.stdin:
            token = stdin_line(200).decode("ascii")
        else:
            if not sys.stdin.isatty():
                raise AdapterError("use_explicit_stdin_bootstrap")
            token = getpass.getpass("Short MALMOA Plugin credential: ")
        profile = Profile(
            gateway_origin=args.gateway_origin,
            plugin_token=SecretStr(token),
            client=args.client,
            destination_id=args.destination,
        )
        profile.check_client(args.client)
        Adapter(Gateway(profile))  # Verify scope before storing. Never forwards native tokens.
        save_profile(args.profile, profile)
        print("MALMOA Plugin credential stored in the OS credential store.", file=sys.stderr)
        return
    profile = bootstrap_profile() if args.command == "serve-stdin" else load_profile(args.profile)
    profile.check_client(args.client)
    create_server(Adapter(Gateway(profile))).run(transport="stdio")


def main() -> None:
    # No dependency debug logging or input/response exception tracebacks.
    logging.disable(logging.CRITICAL)
    try:
        execute(build_parser().parse_args())
    except AdapterError as error:
        print("MALMOA: " + str(error), file=sys.stderr)
        raise SystemExit(2) from None
    except (KeyboardInterrupt, BrokenPipeError):
        raise SystemExit(0) from None
    except Exception:
        print("MALMOA: operation_failed", file=sys.stderr)
        raise SystemExit(2) from None


if __name__ == "__main__":
    main()
