"""Fixed-origin project transport and serialized credential rotation."""

import hashlib
import json
import os
import re
import ssl
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Literal
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import HTTPSHandler, ProxyHandler, Request, build_opener
from uuid import uuid4

from cryptography.fernet import Fernet
from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, SecretStr, StrictBool

from malmoa_mcp.credentials import AdapterError
from malmoa_mcp.gateway import NoRedirect
from malmoa_mcp.project_credentials import (
    ProjectProfile,
    load_project_profile,
    save_project_profile,
)
from malmoa_mcp.project_outbox import process_lock, state_root

MAX_PROJECT_RESPONSE_BYTES = 1_048_576


class EventReceipt(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    id: str = Field(min_length=1, max_length=128)
    event_id: str = Field(min_length=1, max_length=128)
    session_id: str = Field(min_length=1, max_length=128)
    sequence: int = Field(ge=0, le=2_147_483_647, strict=True)
    received_at: AwareDatetime
    cursor: int = Field(ge=0, strict=True)
    replayed: StrictBool


def validate_receipt(value: Any, event: dict[str, Any]) -> dict[str, Any]:
    try:
        receipt = EventReceipt.model_validate(value)
        if (receipt.event_id, receipt.session_id, receipt.sequence) != (
            event["event_id"],
            event["session_id"],
            event["sequence"],
        ):
            raise ValueError
        return receipt.model_dump(mode="json")
    except Exception:
        raise AdapterError("invalid_event_receipt") from None


class ProjectConnection(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    id: str
    project_id: str
    source_id: str
    actor_id: str
    host: Literal["codex", "claude"]
    provider: str
    environment_name: str
    actions: list[Literal["read", "capture"]]
    revision: int = Field(ge=1, strict=True)
    state: Literal["active", "expired", "revoked", "unavailable"]
    created_at: datetime
    expires_at: datetime
    last_received_at: datetime | None
    capture_status: Literal["host_capture_not_verified"]


class ProjectTransport:
    def __init__(self, origin: str) -> None:
        self.origin = ProjectProfile.origin(origin)
        self.opener = build_opener(
            ProxyHandler({}), NoRedirect(), HTTPSHandler(context=ssl.create_default_context())
        )

    def request(
        self,
        path: str,
        *,
        body: dict[str, Any] | None = None,
        token: SecretStr | None = None,
        scheme: str = "ProjectPlugin",
        method: str | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        # Callers use only fixed route families and validated opaque identifiers.
        if not path.startswith("/api/v1/") or "#" in path or ".." in path:
            raise AdapterError("invalid_project_operation")
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if token is not None:
            headers["Authorization"] = scheme + " " + token.get_secret_value()
        if idempotency_key:
            if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", idempotency_key):
                raise AdapterError("invalid_event_id")
            headers["Idempotency-Key"] = idempotency_key
        request = Request(
            self.origin + path,
            data=json.dumps(body).encode("utf-8") if body is not None else None,
            headers=headers,
            method=method or ("POST" if body is not None else "GET"),
        )
        try:
            with self.opener.open(request, timeout=10) as response:
                if response.status == 204:
                    return {}
                data = response.read(MAX_PROJECT_RESPONSE_BYTES + 1)
                if len(data) > MAX_PROJECT_RESPONSE_BYTES:
                    raise AdapterError("project_response_too_large")
                value = json.loads(data)
                if not isinstance(value, dict):
                    raise AdapterError("invalid_project_response")
                return value
        except HTTPError as error:
            if error.code in {401, 403, 404, 410}:
                raise AdapterError("project_access_denied") from None
            if error.code in {400, 409, 422}:
                raise AdapterError("project_event_rejected") from None
            if error.code == 429:
                raise AdapterError("project_rate_limited") from None
            raise AdapterError("project_unavailable") from None
        except (URLError, TimeoutError, OSError):
            raise AdapterError("project_delivery_unknown") from None
        except (ValueError, UnicodeError):
            raise AdapterError("invalid_project_response") from None


class ProjectGateway:
    def __init__(self, name: str, client: str, *, root: Path | None = None) -> None:
        self.name, self.client = name, client
        self.root = root or state_root()
        profile = load_project_profile(name)
        profile.check_client(client)
        self.transport = ProjectTransport(profile.gateway_origin)
        self.profile = profile

    def _refresh_journal(self, profile: ProjectProfile, *, begin: bool = False) -> None:
        # This independent encrypted journal is under the credentials lock, never
        # the capture queue lock. It remains durable even if OS-store writes fail
        # after the server has consumed a refresh token.
        directory = self.root / (self.name + ".credentials")
        path = directory / "refresh.enc"
        cipher = Fernet(profile.outbox_key.get_secret_value().encode("ascii"))
        fingerprint = hashlib.sha256(profile.refresh_token.get_secret_value().encode()).hexdigest()
        if path.exists():
            try:
                if path.is_symlink() or path.stat().st_size > 4096:
                    raise ValueError
                previous = json.loads(cipher.decrypt(path.read_bytes()))
                if previous["connection_id"] != profile.connection_id:
                    raise ValueError
                if previous["refresh_fingerprint"] == fingerprint:
                    raise AdapterError("project_login_required")
                # A different protected token means replacement was durably saved.
                path.unlink()
            except AdapterError:
                raise
            except Exception:
                raise AdapterError("project_refresh_journal_invalid") from None
        if begin:
            temporary = directory / ("refresh." + uuid4().hex + ".tmp")
            payload = cipher.encrypt(
                json.dumps(
                    {"connection_id": profile.connection_id, "refresh_fingerprint": fingerprint}
                ).encode()
            )
            fd = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            try:
                with os.fdopen(fd, "wb") as stream:
                    stream.write(payload)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temporary, path)
                if os.name != "nt":
                    directory_fd = os.open(directory, os.O_RDONLY)
                    try:
                        os.fsync(directory_fd)
                    finally:
                        os.close(directory_fd)
            finally:
                temporary.unlink(missing_ok=True)

    def _profile(self) -> ProjectProfile:
        profile = load_project_profile(self.name)
        profile.check_client(self.client)
        if (profile.gateway_origin, profile.connection_id) != (
            self.profile.gateway_origin,
            self.profile.connection_id,
        ):
            raise AdapterError("project_profile_changed")
        if profile.refresh_uncertain:
            raise AdapterError("project_login_required")
        self._refresh_journal(profile)
        if profile.access_expires_at <= datetime.now(UTC) + timedelta(seconds=30):
            self._refresh_journal(profile, begin=True)
            try:
                result = self.transport.request(
                    "/api/v1/project-agent/refresh",
                    body={"refresh_token": profile.refresh_token.get_secret_value()},
                )
                connection = validate_connection(result.get("connection"), profile)
                replacement = profile.model_copy(
                    update={
                        "access_token": SecretStr(result["access_token"]),
                        "refresh_token": SecretStr(result["refresh_token"]),
                        "access_expires_at": datetime.fromisoformat(result["access_expires_at"]),
                    }
                )
                replacement = ProjectProfile.model_validate_json(replacement.protected_json())
                validate_connection(connection.model_dump(), replacement)
                save_project_profile(self.name, replacement)
                profile = replacement
                self._refresh_journal(profile)
            except AdapterError as error:
                if str(error) not in {
                    "project_access_denied",
                    "project_event_rejected",
                    "project_rate_limited",
                }:
                    save_project_profile(
                        self.name, profile.model_copy(update={"refresh_uncertain": True})
                    )
                else:
                    # Explicit pre-commit denials may be retried after correction.
                    (self.root / (self.name + ".credentials") / "refresh.enc").unlink(
                        missing_ok=True
                    )
                raise
            except Exception:
                # A successful rotation with an invalid response cannot safely be retried.
                save_project_profile(
                    self.name, profile.model_copy(update={"refresh_uncertain": True})
                )
                raise AdapterError("project_login_required") from None
        self.profile = profile
        return profile

    def request(
        self,
        path: str,
        body: dict[str, Any] | None = None,
        *,
        action: str | None = "read",
        method: str | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        if not path.startswith("/api/v1/project-agent/"):
            raise AdapterError("invalid_project_operation")
        with process_lock(self.root / (self.name + ".credentials")):
            profile = self._profile()
            current = validate_connection(
                self.transport.request(
                    "/api/v1/project-agent/connection", token=profile.access_token
                ),
                profile,
            )
            if action is not None and action not in current.actions:
                raise AdapterError("project_action_denied")
            if path == "/api/v1/project-agent/connection":
                return current.model_dump(mode="json")
            return self.transport.request(
                path,
                body=body,
                token=profile.access_token,
                method=method,
                idempotency_key=idempotency_key,
            )

    def handoff(
        self,
        after: int = 0,
        through_cursor: int | None = None,
        work_after: str = "",
    ) -> dict[str, Any]:
        if isinstance(after, bool) or after < 0:
            raise AdapterError("invalid_handoff_cursor")
        # Provenance attestation can be costly for large imported documents.
        # Keep each page within the bounded transport timeout; callers follow cursors.
        parameters = {"after": after, "limit": 1}
        if not re.fullmatch(r"[A-Za-z0-9-]{0,36}", work_after):
            raise AdapterError("invalid_work_cursor")
        if through_cursor is not None:
            if isinstance(through_cursor, bool) or through_cursor < after:
                raise AdapterError("invalid_handoff_cursor")
            parameters["through_cursor"] = through_cursor
        result = self.request(
            "/api/v1/project-agent/handoff?" + urlencode({**parameters, "work_after": work_after})
        )
        if result.get("project_id") != self.profile.project_id:
            raise AdapterError("handoff_scope_mismatch")
        required = {
            "server_time",
            "from_cursor",
            "through_cursor",
            "next_cursor",
            "has_more",
            "coverage",
            "capture_status",
            "decisions",
            "actions",
            "contexts",
            "records",
            "omissions",
            "connection_id",
            "work",
            "work_from_after",
            "work_next_after",
        }
        if not required <= result.keys():
            raise AdapterError("invalid_handoff_response")
        if result.get("connection_id") != self.profile.connection_id:
            raise AdapterError("handoff_connection_mismatch")
        return {"trust": "untrusted_source_material", **result}


def validate_connection(value: Any, profile: ProjectProfile) -> ProjectConnection:
    try:
        row = ProjectConnection.model_validate(value)
    except Exception:
        raise AdapterError("invalid_project_connection") from None
    if (row.id, row.project_id, row.source_id, row.actor_id, row.host) != (
        profile.connection_id,
        profile.project_id,
        profile.source_id,
        profile.actor_id,
        profile.client,
    ):
        raise AdapterError("project_connection_scope_changed")
    if (
        row.state != "active"
        or row.expires_at.tzinfo is None
        or row.expires_at <= datetime.now(UTC)
    ):
        raise AdapterError("project_connection_unavailable")
    if row.provider != {"codex": "openai", "claude": "anthropic"}[profile.client]:
        raise AdapterError("project_provider_mismatch")
    return row
