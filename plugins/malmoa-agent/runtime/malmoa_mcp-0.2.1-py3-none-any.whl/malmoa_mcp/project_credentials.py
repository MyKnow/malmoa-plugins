"""Project-only credentials. Account sessions never enter the MCP process."""

import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

from cryptography.fernet import Fernet
from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator

from malmoa_mcp.credentials import AdapterError, Profile, os_store, profile_name

PROJECT_SERVICE = "MALMOA.MCP.ProjectConnection.v1"


class ProjectProfile(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, hide_input_in_errors=True)
    gateway_origin: str
    connection_id: str = Field(min_length=1, max_length=128)
    project_id: str = Field(min_length=1, max_length=128)
    source_id: str = Field(min_length=1, max_length=128)
    actor_id: str = Field(min_length=1, max_length=128)
    client: Literal["codex", "claude"]
    workspace: str
    access_token: SecretStr = Field(repr=False)
    refresh_token: SecretStr = Field(repr=False)
    access_expires_at: datetime
    enrolled_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    outbox_key: SecretStr = Field(repr=False)
    refresh_uncertain: bool = False

    @field_validator("gateway_origin")
    @classmethod
    def origin(cls, value: str) -> str:
        return Profile.trusted_origin(value)

    @field_validator("workspace")
    @classmethod
    def workspace_path(cls, value: str) -> str:
        path = Path(value)
        if not path.is_absolute() or not path.is_dir():
            raise ValueError("explicit existing absolute workspace required")
        return str(path.resolve())

    @field_validator("access_token", "refresh_token")
    @classmethod
    def scoped_token(cls, value: SecretStr) -> SecretStr:
        if not re.fullmatch(r"mp[ar]_[A-Za-z0-9_-]{43}", value.get_secret_value()):
            raise ValueError("scoped project credential required")
        return value

    @field_validator("access_expires_at", "enrolled_at")
    @classmethod
    def aware_expiry(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("aware expiry required")
        return value

    @field_validator("outbox_key")
    @classmethod
    def encryption_key(cls, value: SecretStr) -> SecretStr:
        Fernet(value.get_secret_value().encode("ascii"))
        return value

    def check_client(self, client: str) -> None:
        if client != self.client:
            raise AdapterError("project_client_mismatch")
        if not self.access_token.get_secret_value().startswith("mpa_") or not (
            self.refresh_token.get_secret_value().startswith("mpr_")
        ):
            raise AdapterError("invalid_project_credential")

    def check_workspace(self, cwd: str) -> None:
        try:
            Path(cwd).resolve(strict=True).relative_to(Path(self.workspace))
        except (ValueError, OSError):
            raise AdapterError("workspace_out_of_scope") from None

    def protected_json(self) -> str:
        value = self.model_dump(mode="json")
        for key in ("access_token", "refresh_token", "outbox_key"):
            value[key] = getattr(self, key).get_secret_value()
        return json.dumps(value, separators=(",", ":"))


def save_project_profile(name: str, profile: ProjectProfile) -> None:
    name = profile_name(name)
    profile.check_client(profile.client)
    try:
        os_store().set_password(PROJECT_SERVICE, name, profile.protected_json())
    except Exception:
        raise AdapterError("protected_project_store_write_failed") from None


def load_project_profile(name: str) -> ProjectProfile:
    name = profile_name(name)
    try:
        stored = os_store().get_password(PROJECT_SERVICE, name)
        if stored is None:
            raise AdapterError("project_credential_missing")
        profile = ProjectProfile.model_validate_json(stored)
        profile.check_client(profile.client)
        return profile
    except AdapterError:
        raise
    except Exception:
        raise AdapterError("protected_project_store_read_failed") from None


def delete_project_profile(name: str) -> None:
    name = profile_name(name)
    try:
        os_store().delete_password(PROJECT_SERVICE, name)
    except Exception:
        raise AdapterError("protected_project_store_delete_failed") from None
