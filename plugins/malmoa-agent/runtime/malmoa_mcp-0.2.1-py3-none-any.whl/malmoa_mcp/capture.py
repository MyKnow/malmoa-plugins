"""Explicit host transcript adapters. Never scan host history or capture reasoning."""

import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from malmoa_mcp.credentials import AdapterError
from malmoa_mcp.project_gateway import ProjectGateway, validate_receipt
from malmoa_mcp.project_outbox import Outbox, state_root

MAX_TRANSCRIPT_BYTES = 16_000_000
MAX_EVENTS_PER_SYNC = 20
SENSITIVE = re.compile(
    r"(?:\b(?:mp[acgr]_|sk-(?:proj-)?|gh[pousr]_)[A-Za-z0-9_-]{16,}"
    r"|-----BEGIN [A-Z ]*PRIVATE KEY-----"
    r"|\b(?:password|passwd|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|authorization)"
    r"[\"']?\s*[:=]\s*[\"']?\S+)",
    re.IGNORECASE,
)
SECRET_TOOLS = re.compile(
    r"(?:malmoa_use_secret|malmoa_sign_payload|secret.*(?:reveal|resolve|use)|"
    r"(?:get|read|reveal).*secret|(?:login|credential|password)|"
    r"malmoa_context_(?:read|query)|malmoa_read_context)",
    re.IGNORECASE,
)
PROJECT_READ = re.compile(
    r"malmoa_project_handoff|malmoa_work_read|malmoa_context_list|malmoa_context_read|malmoa_context_asset",
    re.IGNORECASE,
)
DIRECT_PROJECT_READ = re.compile(
    r"(?:mcp__[A-Za-z0-9_-]+__)?(?:malmoa_project_handoff|malmoa_work_read|"
    r"malmoa_context_list|malmoa_context_read|malmoa_context_asset)",
    re.IGNORECASE,
)


def project_tool_discovery(name: str, arguments: Any) -> bool:
    """Recognize Claude's explicit metadata selection, which does not run a tool."""
    if (
        name != "ToolSearch"
        or not isinstance(arguments, dict)
        or set(arguments) - {"query", "max_results"}
        or not isinstance(arguments.get("query"), str)
        or not arguments["query"].startswith("select:")
        or len(arguments["query"]) > 1000
        or (
            "max_results" in arguments
            and (
                type(arguments["max_results"]) is not int or not 1 <= arguments["max_results"] <= 20
            )
        )
    ):
        return False
    names = arguments["query"][7:].split(",")
    return bool(names) and all(
        DIRECT_PROJECT_READ.fullmatch(tool)
        or re.fullmatch(r"(?:mcp__[A-Za-z0-9_-]+__)?malmoa_project_status", tool)
        for tool in names
    )


def sensitive_operation(name: str, arguments: Any) -> bool:
    """Direct project reads stay pending until their same-connection result arrives.

    Wrapped/unknown operations and secret-bearing arguments remain conservative.
    A legacy pinned read without project attestation is still quarantined.
    """
    if project_tool_discovery(name, arguments):
        return contains_sensitive(arguments)
    return bool(
        (SECRET_TOOLS.search(name) and not DIRECT_PROJECT_READ.fullmatch(name))
        or SECRET_TOOLS.search(arguments if isinstance(arguments, str) else json.dumps(arguments))
    )


def contains_sensitive(value: Any) -> bool:
    """Bounded recursive inspection, including JSON strings with escaped quotes.

    This is an exclusion heuristic; it cannot establish that arbitrary data is
    free of secrets. Known operation/session quarantine remains the primary gate.
    """
    nodes = 0
    characters = 0

    def inspect(item: Any, depth: int) -> bool:
        nonlocal nodes, characters
        nodes += 1
        if nodes > 10_000 or depth > 32:
            return True
        if isinstance(item, str):
            characters += len(item)
            if characters > 1_048_576 or SENSITIVE.search(item):
                return True
            try:
                decoded = json.loads(item)
            except ValueError:
                return False
            return inspect(decoded, depth + 1) if decoded != item else False
        if isinstance(item, dict):
            for key, child in item.items():
                if re.fullmatch(
                    r"(?:password|passwd|api[_ -]?key|access[_ -]?token|"
                    r"refresh[_ -]?token|authorization)",
                    str(key),
                    re.IGNORECASE,
                ):
                    if child is not None and child != "":
                        return True
                if inspect(child, depth + 1):
                    return True
            return False
        if isinstance(item, list):
            return any(inspect(child, depth + 1) for child in item)
        return False

    return inspect(value, 0)


def attested_scope(text: str, scope: tuple[str, str] | None) -> bool:
    if scope is None or len(text) > 1_048_576:
        return False
    pairs: list[tuple[str, str]] = []
    projects: list[str] = []

    def visit(value: Any, depth: int = 0) -> None:
        if depth > 8:
            return
        if isinstance(value, str):
            try:
                visit(json.loads(value), depth + 1)
            except ValueError:
                pass
        elif isinstance(value, dict):
            if isinstance(value.get("project_id"), str):
                projects.append(value["project_id"])
                if isinstance(value.get("connection_id"), str):
                    pairs.append((value["project_id"], value["connection_id"]))
            for child in value.values():
                visit(child, depth + 1)
        elif isinstance(value, list):
            for child in value:
                visit(child, depth + 1)

    visit(text)
    return (
        bool(pairs)
        and all(pair == scope for pair in pairs)
        and all(project == scope[0] for project in projects)
    )


@dataclass
class TranscriptResult:
    events: list[dict[str, Any]] = field(default_factory=list)
    omissions: list[str] = field(default_factory=list)
    coverage: str = "partial_host_transcript"


def _text(content: Any) -> str | None:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        # Tool outputs may be text/image arrays. Never stringify arbitrary objects.
        text = [
            row["text"]
            for row in content
            if isinstance(row, dict)
            and row.get("type") in {"text", "input_text", "output_text"}
            and isinstance(row.get("text"), str)
        ]
        return "\n".join(text) or None
    return None


def normalize_transcript(
    client: str,
    lines: list[str],
    session_id: str,
    *,
    scope: tuple[str, str] | None = None,
) -> TranscriptResult:
    result = TranscriptResult()
    secret_session = False
    pending_reads: set[str] = set()
    discoveries: set[str] = set()
    observed = datetime.now(UTC).isoformat()
    for line_index, line in enumerate(lines):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
            if not isinstance(row, dict):
                raise ValueError
        except ValueError:
            result.omissions.append("incomplete_or_invalid_record")
            continue
        timestamp = row.get("timestamp", observed)
        timestamp_trusted = "timestamp" in row
        try:
            parsed_time = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
            if parsed_time.tzinfo is None:
                raise ValueError
        except (ValueError, AttributeError, TypeError):
            timestamp = observed
            timestamp_trusted = False
            result.omissions.append("host_timestamp_unavailable")
        chunks: list[tuple[str, str]] = []
        if client == "claude" and row.get("type") in {"user", "assistant"}:
            message = row.get("message")
            if not isinstance(message, dict):
                result.omissions.append("unsupported_record")
                continue
            if message.get("channel") in {"analysis", "reasoning"} or row.get("channel") in {
                "analysis",
                "reasoning",
            }:
                continue
            content = message.get("content")
            if isinstance(content, str):
                chunks.append((row["type"], content))
            elif isinstance(content, list):
                for block in content:
                    if not isinstance(block, dict):
                        result.omissions.append("unsupported_content_block")
                        continue
                    if block.get("type") == "tool_use":
                        if project_tool_discovery(str(block.get("name", "")), block.get("input")):
                            discoveries.add(str(block.get("id", "")))
                            result.omissions.append("tool_discovery_metadata_excluded")
                            continue
                        if sensitive_operation(str(block.get("name", "")), block.get("input", {})):
                            secret_session = True
                        if PROJECT_READ.search(str(block.get("name", ""))) or PROJECT_READ.search(
                            json.dumps(block.get("input", {}))
                        ):
                            pending_reads.add(str(block.get("id", "")))
                        # Tool arguments can contain arbitrary file contents/credentials.
                        result.omissions.append("tool_arguments_excluded")
                    elif block.get("type") == "text" and isinstance(block.get("text"), str):
                        chunks.append((row["type"], block["text"]))
                    elif block.get("type") == "tool_result":
                        value = _text(block.get("content"))
                        read_id = str(block.get("tool_use_id", ""))
                        if read_id in discoveries:
                            discoveries.remove(read_id)
                            if contains_sensitive(block.get("content")):
                                secret_session = True
                            continue
                        if read_id in pending_reads:
                            pending_reads.remove(read_id)
                            if not value or not attested_scope(value, scope):
                                secret_session = True
                                result.omissions.append("unattested_context_read_quarantined")
                        if value:
                            chunks.append(("tool", value))
                    elif block.get("type") not in {"thinking", "redacted_thinking"}:
                        result.omissions.append("unsupported_content_block")
            else:
                result.omissions.append("unsupported_content_block")
        elif client == "codex" and row.get("type") == "response_item":
            payload = row.get("payload")
            if not isinstance(payload, dict):
                result.omissions.append("unsupported_record")
                continue
            if payload.get("type") == "message" and payload.get("role") in {"user", "assistant"}:
                if payload.get("channel") in {"analysis", "reasoning"} or payload.get("phase") in {
                    "analysis",
                    "reasoning",
                }:
                    continue
                value = _text(payload.get("content"))
                if value:
                    chunks.append((payload["role"], value))
            elif payload.get("type") in {"function_call", "custom_tool_call"}:
                if sensitive_operation(
                    str(payload.get("name", "")), payload.get("arguments", payload.get("input", ""))
                ):
                    secret_session = True
                if PROJECT_READ.search(str(payload.get("name", ""))) or PROJECT_READ.search(
                    str(payload.get("arguments", payload.get("input", "")))
                ):
                    pending_reads.add(str(payload.get("call_id", "")))
                result.omissions.append("tool_arguments_excluded")
            elif payload.get("type") in {"function_call_output", "custom_tool_call_output"}:
                value = _text(payload.get("output"))
                read_id = str(payload.get("call_id", ""))
                if read_id in pending_reads:
                    pending_reads.remove(read_id)
                    if not value or not attested_scope(value, scope):
                        secret_session = True
                        result.omissions.append("unattested_context_read_quarantined")
                if value:
                    chunks.append(("tool", value))
            elif payload.get("type") != "reasoning":
                result.omissions.append("unsupported_record")
        elif row.get("type") in {
            "session_meta",
            "turn_context",
            "event_msg",
            "system",
            "progress",
            "file-history-snapshot",
            "summary",
        }:
            # These include internal context and reasoning duplicates in some hosts.
            continue
        else:
            result.omissions.append("unsupported_record")
        for block_index, (kind, text) in enumerate(chunks):
            if secret_session or contains_sensitive(text):
                secret_session = True
                result.omissions.append("sensitive_session_quarantined")
                continue
            if pending_reads:
                result.omissions.append("unattested_intermediate_output_excluded")
                continue
            if not text.strip() or "\x00" in text:
                result.omissions.append("invalid_record_excluded")
                continue
            if len(text) > 40_000 or len(text.encode("utf-8")) > 120_000:
                result.omissions.append("oversized_record_excluded")
                continue
            event_seed = f"{client}\0{session_id}\0{line_index}\0{block_index}\0{kind}\0{text}"
            result.events.append(
                {
                    "event_id": hashlib.sha256(event_seed.encode()).hexdigest(),
                    "session_id": session_id,
                    "sequence": line_index * 100 + block_index,
                    "kind": kind,
                    "text": text,
                    "observed_at": timestamp,
                    "summary": None,
                    "remaining_work": None,
                    "sensitive": False,
                    "_source_line": line_index,
                    "_timestamp_trusted": timestamp_trusted,
                }
            )
    if secret_session:
        result.omissions.append("sensitive_session_quarantined")
    if pending_reads:
        # PreToolUse can see the call before its result has been written. Keep
        # derived output blocked until attestation arrives, without permanently
        # quarantining a valid same-connection read merely because it is in flight.
        result.omissions.append("context_read_pending")
    result.omissions = sorted(set(result.omissions))
    return result


def synchronize(gateway: ProjectGateway) -> dict[str, Any]:
    profile = gateway.profile
    queue = Outbox(gateway.root, gateway.name, profile)
    # Check current permission before reading/replaying any local queued source.
    gateway.request("/api/v1/project-agent/connection", action="capture")
    delivered = 0
    started = time.monotonic()
    with queue.transaction() as state:
        while state["pending"] and delivered < MAX_EVENTS_PER_SYNC:
            if time.monotonic() - started > 20:
                state["status"] = "pending"
                break
            event = state["pending"][0]
            try:
                if event.get("_operation") in {"work_create", "work_report"}:
                    work_id = event.get("work_id")
                    if work_id is not None and not re.fullmatch(r"[A-Za-z0-9-]{1,64}", work_id):
                        raise AdapterError("invalid_work_id")
                    path = "/api/v1/project-agent/work" + ("/" + work_id if work_id else "")
                    response = gateway.request(
                        path,
                        event["body"],
                        action="capture",
                        method="PATCH" if work_id else "POST",
                        idempotency_key=event["operation_id"],
                    )
                    if (
                        not isinstance(response.get("id"), str)
                        or type(response.get("revision")) is not int
                    ):
                        raise AdapterError("invalid_work_receipt")
                    if response.get("project_id") != profile.project_id:
                        raise AdapterError("work_scope_mismatch")
                    if response.get("connection_id") != profile.connection_id:
                        raise AdapterError("work_scope_mismatch")
                    receipt = {
                        "work_id": response["id"],
                        "revision": response["revision"],
                        "fingerprint": event["fingerprint"],
                        "source": "agent_reported",
                        "verification": "unverified",
                    }
                    receipts = state.setdefault("work_receipts", {})
                    if len(receipts) >= 1000:
                        raise AdapterError("outbox_capacity_exceeded")
                    receipts[event["operation_id"]] = receipt
                else:
                    receipt = validate_receipt(
                        gateway.request("/api/v1/project-agent/events", event, action="capture"),
                        event,
                    )
            except AdapterError as error:
                state["status"] = str(error)
                break
            state["last_ack"] = receipt
            state["pending"].pop(0)
            delivered += 1
        else:
            state["status"] = "received" if not state["pending"] else "pending"
        return {
            "status": state["status"],
            "pending": len(state["pending"]),
            "delivered": delivered,
            "last_ack": state["last_ack"],
            "capture_coverage": "partial_host_transcript",
        }


def capture_hook(
    name: str,
    client: str,
    payload: dict[str, Any],
    *,
    send: bool = True,
) -> dict[str, Any]:
    gateway = ProjectGateway(name, client)
    profile = gateway.profile
    cwd, session_id, transcript = (
        payload.get("cwd"),
        payload.get("session_id"),
        payload.get("transcript_path"),
    )
    if not isinstance(cwd, str):
        raise AdapterError("hook_workspace_missing")
    profile.check_workspace(cwd)
    if not isinstance(session_id, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", session_id):
        raise AdapterError("invalid_host_session")
    parent_session: str | None = None
    if payload.get("hook_event_name") == "SubagentStop":
        parent_session = session_id
        agent_id = payload.get("agent_id")
        if not isinstance(agent_id, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", agent_id):
            raise AdapterError("invalid_host_subagent")
        session_id = (
            "subagent-" + hashlib.sha256((session_id + "\0" + agent_id).encode()).hexdigest()
        )
        transcript = payload.get("agent_transcript_path")
    if not isinstance(transcript, str):
        raise AdapterError("host_transcript_unavailable")
    path = Path(transcript)
    # Only the exact host-provided transcript path, never directories/history scans.
    if not path.is_absolute() or path.suffix != ".jsonl" or path.is_symlink():
        raise AdapterError("invalid_host_transcript_path")
    try:
        if path.stat().st_size > MAX_TRANSCRIPT_BYTES:
            raise AdapterError("host_transcript_too_large")
        text = path.read_text(encoding="utf-8")
    except OSError:
        raise AdapterError("host_transcript_unavailable") from None
    result = normalize_transcript(
        client, text.splitlines(), session_id, scope=(profile.project_id, profile.connection_id)
    )
    eligible = []
    for record in result.events:
        trusted_time = record.pop("_timestamp_trusted", False)
        if not trusted_time or datetime.fromisoformat(record["observed_at"]) < profile.enrolled_at:
            result.omissions.append("pre_enrollment_or_unknown_time_history_excluded")
        else:
            eligible.append(record)
    result.events = eligible
    # Both hosts expose the current final response separately: transcript writes
    # can lag Stop. Capture it without inspecting internal reasoning fields.
    last_assistant = payload.get("last_assistant_message")
    if (
        isinstance(last_assistant, str)
        and last_assistant
        and not any(
            event["kind"] == "assistant" and event["text"] == last_assistant
            for event in result.events
        )
    ):
        if "context_read_pending" in result.omissions:
            pass  # A direct Stop response cannot attest the outstanding read.
        elif "sensitive_session_quarantined" in result.omissions or contains_sensitive(
            last_assistant
        ):
            result.omissions.append("sensitive_session_quarantined")
        elif len(last_assistant) <= 40_000:
            result.events.append(
                {
                    "event_id": hashlib.sha256(
                        (
                            session_id
                            + "\0stop\0"
                            + str(payload.get("turn_id", len(text.splitlines())))
                            + "\0"
                            + last_assistant
                        ).encode()
                    ).hexdigest(),
                    "session_id": session_id,
                    "sequence": 0,
                    "kind": "assistant",
                    "text": last_assistant,
                    "observed_at": datetime.now(UTC).isoformat(),
                    "summary": None,
                    "remaining_work": None,
                    "sensitive": False,
                    "_fallback": True,
                    "_from_line": len(text.splitlines())
                    - (1 if "incomplete_or_invalid_record" in result.omissions else 0),
                }
            )
            result.omissions.append("stop_response_fallback")
    queue = Outbox(state_root(), name, profile)
    with queue.transaction() as state:
        previous = state["sessions"].get(session_id, {})
        if (
            previous.get("quarantined")
            or (
                parent_session is not None
                and state["sessions"].get(parent_session, {}).get("quarantined")
            )
            or sensitive_operation(str(payload.get("tool_name", "")), payload.get("tool_input", {}))
        ):
            result.events = []
            result.omissions.append("sensitive_session_quarantined")
        seen = previous.get("seen", [])
        known = set(seen)
        scoped_events = []
        sequence = previous.get("last_sequence", -1)
        fallbacks = previous.get("fallbacks", [])
        checkpoint = json.dumps(
            {
                "host_format": client + "-jsonl-v1-observed",
                "coverage": result.coverage,
                "omissions": sorted(set(result.omissions)),
                "hook_event": str(payload.get("hook_event_name", "unknown"))[:100],
                "parent_session_id": parent_session,
            },
            sort_keys=True,
        )
        result.events.append(
            {
                "event_id": hashlib.sha256((session_id + checkpoint).encode()).hexdigest(),
                "session_id": session_id,
                "sequence": 0,
                "kind": "checkpoint",
                "text": checkpoint,
                "observed_at": datetime.now(UTC).isoformat(),
                "summary": None,
                "remaining_work": None,
                "sensitive": False,
                "_checkpoint": True,
            }
        )
        for event in result.events:
            source_line = event.pop("_source_line", None)
            fallback = event.pop("_fallback", False)
            from_line = event.pop("_from_line", 0)
            checkpoint_event = event.pop("_checkpoint", False)
            namespace = profile.project_id + "\0" + profile.actor_id + "\0" + profile.client
            if checkpoint_event:
                namespace += "\0" + profile.connection_id
            event["event_id"] = hashlib.sha256(
                (namespace + "\0" + event["event_id"]).encode()
            ).hexdigest()
            text_hash = hashlib.sha256(event["text"].encode()).hexdigest()
            if event["kind"] == "assistant" and source_line is not None:
                matching = next(
                    (
                        row
                        for row in fallbacks
                        if row["text_hash"] == text_hash and source_line >= row["from_line"]
                    ),
                    None,
                )
                if matching is not None:
                    # Reconcile only one future record with the lagging Stop
                    # fallback. Later identical legitimate responses are retained.
                    fallbacks.remove(matching)
                    if event["event_id"] not in known:
                        known.add(event["event_id"])
                        seen.append(event["event_id"])
                    continue
            if event["event_id"] not in known:
                sequence += 1
                if sequence > 2_147_483_647:
                    raise AdapterError("session_sequence_exhausted")
                event["sequence"] = sequence
                scoped_events.append(event)
                seen.append(event["event_id"])
                known.add(event["event_id"])
                if fallback:
                    fallbacks.append({"text_hash": text_hash, "from_line": from_line})
        state["pending"].extend(scoped_events)
        # Bounds are enforced before the cursor/seen list can be durably advanced.
        if len(seen) > 25_000 or len(state["sessions"]) > 1000:
            raise AdapterError("outbox_capacity_exceeded")
        state["sessions"][session_id] = {
            "seen": seen,
            "omissions": result.omissions,
            "last_sequence": sequence,
            "fallbacks": fallbacks,
            "quarantined": "sensitive_session_quarantined" in result.omissions,
            "context_read_pending": "context_read_pending" in result.omissions,
            "host_format": client + "-jsonl-v1-observed",
            "coverage": result.coverage,
            "hook_event": str(payload.get("hook_event_name", "unknown"))[:100],
        }
        if parent_session is not None and (
            "sensitive_session_quarantined" in result.omissions
            or "context_read_pending" in result.omissions
        ):
            parent_state = state["sessions"].setdefault(parent_session, {})
            parent_state["quarantined"] = True
        state["status"] = "pending" if state["pending"] else state["status"]
    if send:
        try:
            status = synchronize(gateway)
        except AdapterError as error:
            status = {"status": str(error), "pending": len(scoped_events)}
    else:
        status = {"status": "queued_locally", "pending": len(scoped_events)}
    status["omissions"] = result.omissions
    status["capture_coverage"] = result.coverage
    return status
