"""Reported work operations retain their idempotency key across uncertain delivery."""

import hashlib
import json
import re
from typing import Any, Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from malmoa_mcp.capture import contains_sensitive, synchronize
from malmoa_mcp.credentials import AdapterError
from malmoa_mcp.project_gateway import ProjectGateway
from malmoa_mcp.project_outbox import Outbox


class WorkPin(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    candidate_id: str = Field(pattern=r"^[A-Za-z0-9-]{1,36}$")
    revision: int = Field(ge=1, strict=True)


class WorkReport(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    base_revision: int = Field(ge=1, strict=True)
    state: Literal["queued", "running", "blocked", "completed", "failed", "cancelled"] | None = None
    progress: str | None = Field(default=None, max_length=20_000)
    result_summary: str | None = Field(default=None, max_length=20_000)
    remaining_work: str | None = Field(default=None, max_length=20_000)
    changed_files: list[str] | None = Field(default=None, max_length=200)
    test_status: Literal["not_run", "passed", "failed", "unknown"] | None = None
    test_summary: str | None = Field(default=None, max_length=10_000)
    commit: str | None = Field(default=None, pattern=r"^[0-9a-fA-F]{7,64}$")
    change_request_url: str | None = Field(default=None, max_length=2000)
    deployment_url: str | None = Field(default=None, max_length=2000)

    @field_validator("change_request_url", "deployment_url")
    @classmethod
    def safe_url(cls, value: str | None) -> str | None:
        if value is not None:
            parsed = urlsplit(value)
            if (
                parsed.scheme != "https"
                or not parsed.hostname
                or parsed.username
                or parsed.password
            ):
                raise ValueError("HTTPS reference required")
        return value

    @field_validator("changed_files")
    @classmethod
    def file_names(cls, value: list[str] | None) -> list[str] | None:
        if value is not None and (
            len(value) != len(set(value))
            or any(not item.strip() or len(item) > 500 for item in value)
        ):
            raise ValueError("bounded unique file references required")
        return value

    @model_validator(mode="after")
    def changed_report(self) -> "WorkReport":
        fields = self.model_fields_set - {"base_revision"}
        if not fields or any(
            getattr(self, key) is None
            for key in fields - {"commit", "change_request_url", "deployment_url"}
        ):
            raise ValueError("explicit progress fields required")
        return self


def enqueue_work(
    gateway: ProjectGateway,
    operation_id: str,
    body: dict[str, Any],
    work_id: str | None = None,
) -> dict[str, Any]:
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", operation_id):
        raise AdapterError("invalid_work_operation_id")
    if work_id is not None and not re.fullmatch(r"[A-Za-z0-9-]{1,64}", work_id):
        raise AdapterError("invalid_work_id")
    if contains_sensitive(body):
        raise AdapterError("sensitive_capture_excluded")
    gateway.request("/api/v1/project-agent/connection", action="capture")
    identifier = hashlib.sha256(
        (gateway.profile.connection_id + "\0" + operation_id).encode()
    ).hexdigest()
    fingerprint = hashlib.sha256(
        json.dumps({"body": body, "work_id": work_id}, sort_keys=True).encode()
    ).hexdigest()
    queue = Outbox(gateway.root, gateway.name, gateway.profile)
    with queue.transaction() as state:
        if any(session.get("quarantined") for session in state["sessions"].values()):
            raise AdapterError("sensitive_profile_requires_host_capture")
        if any(session.get("context_read_pending") for session in state["sessions"].values()):
            raise AdapterError("project_context_read_pending")
        receipts = state.setdefault("work_receipts", {})
        if identifier in receipts:
            if receipts[identifier]["fingerprint"] != fingerprint:
                raise AdapterError("work_operation_payload_changed")
            return {
                "operation_id": operation_id,
                "receipt": receipts[identifier],
                "status": "received",
                "pending": len(state["pending"]),
                "delivered": 0,
                "last_ack": state["last_ack"],
                "capture_coverage": "partial_host_transcript",
                "source": "agent_reported",
                "verification": "unverified",
            }
        existing = next(
            (row for row in state["pending"] if row.get("operation_id") == identifier), None
        )
        if existing is not None:
            if existing["fingerprint"] != fingerprint or existing.get("work_id") != work_id:
                raise AdapterError("work_operation_payload_changed")
        else:
            state["pending"].append(
                {
                    "_operation": "work_report" if work_id else "work_create",
                    "operation_id": identifier,
                    "fingerprint": fingerprint,
                    "work_id": work_id,
                    "body": body,
                }
            )
    result = synchronize(gateway)
    with queue.transaction() as state:
        receipt = state.get("work_receipts", {}).get(identifier)
    return {
        "operation_id": operation_id,
        "receipt": receipt,
        **result,
        "source": "agent_reported",
        "verification": "unverified",
    }
