"""Public release installer. Never reads project credentials or capture queues."""

import argparse
import hashlib
import io
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Never, cast

MAX_ARCHIVE = 8 * 1024 * 1024
MAX_EXPANDED = 24 * 1024 * 1024
VERSION = r"[0-9]{1,5}\.[0-9]{1,5}\.[0-9]{1,5}"
CATALOG = "https://github.com/MyKnow/malmoa-plugins.git"


class ReleaseError(Exception):
    """Only fixed, safe error codes cross the CLI boundary."""


@dataclass(frozen=True)
class Release:
    version: str
    path: str
    sha256: str
    size: int


def release_origin(value: str) -> str:
    try:
        parsed = urllib.parse.urlsplit(value)
        if (
            parsed.scheme != "https"
            or not parsed.hostname
            or parsed.username
            or parsed.password
            or parsed.path not in {"", "/"}
            or parsed.query
            or parsed.fragment
            or parsed.port not in {None, 443}
        ):
            raise ValueError
        if not re.fullmatch(r"[A-Za-z0-9.-]+", parsed.hostname):
            raise ValueError
        return f"https://{parsed.hostname.lower()}"
    except (ValueError, TypeError):
        raise ReleaseError("release_https_origin_required") from None


def parse_release(data: bytes) -> Release:
    try:
        item = json.loads(data)
        version, archive = item["version"], item["archive"]
        if (
            type(item["schema_version"]) is not int
            or item["schema_version"] != 1
            or not isinstance(version, str)
            or not re.fullmatch(VERSION, version)
            or archive["path"] != f"/downloads/releases/{version}/malmoa-plugins.zip"
            or not isinstance(archive["sha256"], str)
            or not re.fullmatch(r"[a-f0-9]{64}", archive["sha256"])
            or type(archive["size"]) is not int
            or not 0 < archive["size"] <= MAX_ARCHIVE
            or item["catalog"] != {"name": "malmoa", "repository": CATALOG}
        ):
            raise ValueError
        return Release(version, archive["path"], archive["sha256"], archive["size"])
    except (ValueError, KeyError, TypeError):
        raise ReleaseError("invalid_release_metadata") from None


class SameOriginRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(
        self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str
    ) -> urllib.request.Request | None:
        old, new = urllib.parse.urlsplit(req.full_url), urllib.parse.urlsplit(newurl)
        if (new.scheme, new.netloc) != (old.scheme, old.netloc) or new.username or new.password:
            raise ReleaseError("release_redirect_rejected")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def download(url: str, limit: int) -> bytes:
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "MALMOA-Release/1"})
        with urllib.request.build_opener(SameOriginRedirect()).open(
            request, timeout=30
        ) as response:
            data = response.read(limit + 1)
        if len(data) > limit:
            raise ReleaseError("release_download_too_large")
        return cast(bytes, data)
    except (OSError, urllib.error.URLError):
        raise ReleaseError("release_download_failed") from None


def allowed_member(path: str) -> bool:
    if path in {"README.md", ".agents/plugins/marketplace.json", ".claude-plugin/marketplace.json"}:
        return True
    prefix = "plugins/malmoa-agent/"
    if not path.startswith(prefix):
        return False
    name = path[len(prefix) :]
    if name in {
        "README.md",
        "plugin.json",
        ".codex-plugin/plugin.json",
        ".claude-plugin/plugin.json",
        "scripts/malmoa_plugin.py",
        "runtime/requirements.txt",
        "runtime/bundle.json",
    }:
        return True
    return bool(
        re.fullmatch(r"skills/(connect|context|status|migrate|update)/SKILL\.md", name)
        or re.fullmatch(rf"runtime/malmoa_mcp-{VERSION}-py3-none-any\.whl", name)
    )


def verify_runtime(directory: Path, version: str) -> tuple[Path, Path]:
    wheel = f"malmoa_mcp-{version}-py3-none-any.whl"
    try:
        item = json.loads((directory / "bundle.json").read_text(encoding="utf-8"))
        if (
            item["schema_version"] != 1
            or item["package"] != "malmoa-mcp"
            or item["version"] != version
            or set(item["files"]) != {wheel, "requirements.txt"}
        ):
            raise ValueError
        for name, digest in item["files"].items():
            path = directory / name
            if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                raise ValueError
        return directory / wheel, directory / "requirements.txt"
    except (ValueError, KeyError, TypeError, OSError):
        raise ReleaseError("runtime_integrity_failed") from None


def extract_catalog(data: bytes, target: Path, version: str) -> Path:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            members, names = archive.infolist(), set()
            if len(members) > 64 or sum(m.file_size for m in members) > MAX_EXPANDED:
                raise ValueError
            for member in members:
                parts = PurePosixPath(member.filename).parts
                mode = member.external_attr >> 16
                if (
                    not parts
                    or parts[0] != "malmoa-catalog"
                    or ".." in parts
                    or "\\" in member.filename
                    or member.is_dir()
                    or member.filename in names
                    or PurePosixPath(member.filename).is_absolute()
                    or (stat.S_IFMT(mode) not in {0, stat.S_IFREG})
                    or not allowed_member("/".join(parts[1:]))
                ):
                    raise ValueError
                names.add(member.filename)
            for member in members:
                path = target.joinpath(*PurePosixPath(member.filename).parts)
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("xb") as output:
                    output.write(archive.read(member))
        root = target / "malmoa-catalog"
        plugin = root / "plugins/malmoa-agent"
        for name in ("plugin.json", ".codex-plugin/plugin.json", ".claude-plugin/plugin.json"):
            item = json.loads((plugin / name).read_text(encoding="utf-8"))
            if item["name"] != "malmoa" or item["version"] != version:
                raise ValueError
        for name, expected in (
            (
                ".agents/plugins/marketplace.json",
                {"source": "local", "path": "./plugins/malmoa-agent"},
            ),
            (".claude-plugin/marketplace.json", "./plugins/malmoa-agent"),
        ):
            item = json.loads((root / name).read_text(encoding="utf-8"))
            if item["name"] != "malmoa" or len(item["plugins"]) != 1:
                raise ValueError
            if item["plugins"][0]["name"] != "malmoa" or item["plugins"][0]["source"] != expected:
                raise ValueError
        verify_runtime(plugin / "runtime", version)
        return root
    except (ValueError, KeyError, TypeError, OSError, zipfile.BadZipFile):
        raise ReleaseError("invalid_release_archive") from None


def state_directory() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData/Local")))
        return base / "MALMOA/releases"
    return Path.home() / ".local/share/malmoa/releases"


def load_state(directory: Path) -> dict[str, Any]:
    path = directory / "installation.json"
    if not path.exists():
        return {}
    try:
        item = json.loads(path.read_text(encoding="utf-8"))
        if (
            item["schema_version"] != 1
            or release_origin(item["origin"]) != item["origin"]
            or not re.fullmatch(VERSION, item["version"])
            or not re.fullmatch(r"[0-9a-f]{64}", item["sha256"])
            or not isinstance(item["clients"], list)
            or not item["clients"]
            or not set(item["clients"]) <= {"codex", "claude"}
        ):
            raise ValueError
        return cast(dict[str, Any], item)
    except (ValueError, KeyError, TypeError, OSError):
        raise ReleaseError("invalid_release_installation_state") from None


def run(command: list[str]) -> str:
    try:
        result = subprocess.run(
            command,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            timeout=180,
            check=False,
        )
        if result.returncode:
            raise ReleaseError("release_install_command_failed")
        return result.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        raise ReleaseError("release_install_command_unavailable") from None


def write_update_result(result: dict[str, Any]) -> None:
    directory = state_directory()
    temporary = directory / "update-result.tmp"
    temporary.write_text(json.dumps(result) + "\n", encoding="utf-8")
    temporary.replace(directory / "update-result.json")


def update_status() -> dict[str, Any]:
    try:
        data = (state_directory() / "update-result.json").read_bytes()
        if len(data) > 4096:
            raise ValueError
        result = json.loads(data)
        if not isinstance(result, dict) or result.get("status") not in {
            "started",
            "completed",
            "failed",
        }:
            raise ValueError
        return cast(dict[str, Any], result)
    except FileNotFoundError:
        return {"status": "not_started"}
    except (OSError, ValueError):
        raise ReleaseError("invalid_update_result") from None


def start_windows_update(args: argparse.Namespace) -> dict[str, Any]:
    # The running uv tool cannot safely replace its own Windows environment.
    # Start an independent interpreter and let this CLI exit before installation.
    directory = state_directory()
    previous = load_state(directory)
    origin = release_origin(getattr(args, "server", None) or previous.get("origin", ""))
    if previous and origin != previous["origin"]:
        raise ReleaseError("release_origin_change_requires_new_installation")
    if not shutil.which("uv"):
        raise ReleaseError("release_required_command_missing")
    directory.mkdir(parents=True, exist_ok=True)
    lock = directory / "launch.lock"
    try:
        lock.mkdir()
    except FileExistsError:
        raise ReleaseError("release_update_already_running") from None
    try:
        runner = directory / "update-runner.py"
        runner.write_bytes(Path(__file__).read_bytes())
        command = [
            "uv",
            "run",
            "--no-project",
            "--python",
            "3.12",
            "--managed-python",
            str(runner),
            "update",
            "--server",
            origin,
            "--wait-for-pid",
            str(os.getpid()),
        ]
        if getattr(args, "client", None):
            command.extend(["--client", args.client])
        result = {"status": "started", "completion_command": "malmoa-mcp update --status"}
        write_update_result(result)
        subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=0x00000008 | 0x00000200,
            close_fds=True,
        )
        return result
    except OSError:
        lock.rmdir()
        write_update_result({"status": "failed", "error": "release_runner_start_failed"})
        raise ReleaseError("release_runner_start_failed") from None


def wait_for_parent(pid: int) -> None:
    import ctypes
    from ctypes import wintypes

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel.WaitForSingleObject.restype = wintypes.DWORD
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.OpenProcess(0x00100000, False, pid)
    if not handle:
        if ctypes.get_last_error() == 87:  # type: ignore[attr-defined]
            # Parent already exited.
            return
        raise ReleaseError("release_parent_wait_failed")
    try:
        if kernel.WaitForSingleObject(handle, 30000) != 0:
            raise ReleaseError("release_parent_still_running")
    finally:
        kernel.CloseHandle(handle)


def run_independent_update(args: argparse.Namespace) -> int:
    try:
        wait_for_parent(args.wait_for_pid)
        result = execute_release(args)
        write_update_result({"status": "completed", **result})
        return 0
    except (ReleaseError, OSError) as error:
        code = str(error) if isinstance(error, ReleaseError) else "release_update_failed"
        write_update_result({"status": "failed", "error": code})
        return 2
    finally:
        (state_directory() / "launch.lock").rmdir()


def execute_cli_release(args: argparse.Namespace) -> dict[str, Any]:
    if getattr(args, "status", False):
        return update_status()
    if sys.platform == "win32" and not getattr(args, "check", False):
        return start_windows_update(args)
    return execute_release(args)


def install_runtime(catalog: Path, version: str) -> None:
    wheel, constraints = verify_runtime(catalog / "plugins/malmoa-agent/runtime", version)
    run(
        [
            "uv",
            "tool",
            "install",
            str(wheel),
            "--python",
            "3.12",
            "--constraints",
            str(constraints),
            "--reinstall-package",
            "malmoa-mcp",
        ]
    )


def install_host(client: str, catalog: Path, version: str) -> None:
    # Hosts own their trust and native plugin lifecycle. No private cache edits.
    if client == "codex":
        run(["codex", "plugin", "marketplace", "add", str(catalog), "--json"])
        run(["codex", "plugin", "add", "malmoa@malmoa", "--json"])
        output = run(["codex", "plugin", "list", "--marketplace", "malmoa", "--json"])
    else:
        run(["claude", "plugin", "marketplace", "add", str(catalog)])
        run(["claude", "plugin", "install", "malmoa@malmoa", "--scope", "user"])
        run(["claude", "plugin", "update", "malmoa@malmoa", "--scope", "user"])
        output = run(["claude", "plugin", "list", "--json"])
    # The exact host response shape is adapter-specific; reject an unconfirmed version.
    try:
        rows = json.loads(output)
        entries = rows["installed"] if client == "codex" else rows
        identity = "pluginId" if client == "codex" else "id"
        if not any(
            row.get(identity) == "malmoa@malmoa" and row.get("version") == version
            for row in entries
        ):
            raise ValueError
    except (ValueError, TypeError, KeyError, AttributeError):
        raise ReleaseError("native_plugin_version_not_verified") from None


def execute_release(args: argparse.Namespace) -> dict[str, Any]:
    directory = state_directory()
    previous = load_state(directory)
    supplied_origin = getattr(args, "server", None)
    origin = release_origin(supplied_origin or previous.get("origin", ""))
    if previous and origin != previous["origin"]:
        raise ReleaseError("release_origin_change_requires_new_installation")
    release = parse_release(download(origin + "/downloads/latest.json", 32 * 1024))
    check = getattr(args, "check", False)
    if check:
        return {
            "installed": previous.get("version"),
            "latest": release.version,
            "update_available": previous.get("version") != release.version,
        }
    client = getattr(args, "client", None)
    clients = set(previous.get("clients", []))
    clients.update(["codex", "claude"] if client == "both" else [client] if client else [])
    if not clients:
        raise ReleaseError("release_client_required")
    for name in ["uv", *sorted(clients)]:
        if not shutil.which(name):
            raise ReleaseError("release_required_command_missing")
    data = download(origin + release.path, MAX_ARCHIVE)
    if len(data) != release.size or hashlib.sha256(data).hexdigest() != release.sha256:
        raise ReleaseError("release_archive_integrity_failed")
    directory.mkdir(parents=True, exist_ok=True)
    catalog, backup = directory / "catalog", directory / "previous"
    if (catalog.exists() and not previous) or backup.exists():
        raise ReleaseError("release_recovery_required")
    lock = directory / "update.lock"
    try:
        lock.mkdir()
    except FileExistsError:
        raise ReleaseError("release_update_already_running") from None
    switched = False
    try:
        with tempfile.TemporaryDirectory(prefix="stage-", dir=directory) as temporary:
            staged = extract_catalog(data, Path(temporary), release.version)
            if catalog.exists():
                catalog.rename(backup)
            staged.rename(catalog)
            switched = True
            install_runtime(catalog, release.version)
            for host in sorted(clients):
                install_host(host, catalog, release.version)
            state = {
                "schema_version": 1,
                "origin": origin,
                "version": release.version,
                "sha256": release.sha256,
                "clients": sorted(clients),
            }
            pending = directory / "installation.tmp"
            pending.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
            pending.replace(directory / "installation.json")
        result: dict[str, Any] = {
            "installed": release.version,
            "clients": sorted(clients),
            "restart_hosts": True,
        }
        if backup.exists():
            try:
                shutil.rmtree(backup)
            except OSError:
                result["cleanup_required"] = True
        return result
    except (ReleaseError, OSError):
        if switched:
            if previous and backup.exists():
                failed = directory / "failed"
                if not failed.exists():
                    catalog.rename(failed)
                    backup.rename(catalog)
                    try:
                        install_runtime(catalog, previous["version"])
                        for host in previous["clients"]:
                            install_host(host, catalog, previous["version"])
                        shutil.rmtree(failed)
                    except (ReleaseError, OSError):
                        raise ReleaseError("release_failed_rollback_requires_recovery") from None
            elif not previous:
                # Native/runtime may have installed partially; retain verified files for retry.
                shutil.rmtree(catalog)
        raise ReleaseError("release_install_failed_retry_or_restore") from None
    finally:
        lock.rmdir()


class Parser(argparse.ArgumentParser):
    def error(self, message: str) -> Never:
        raise ReleaseError("invalid_release_arguments")


def main() -> None:
    parser = Parser(description="Install or update the MALMOA native plugin from an HTTPS release.")
    parser.add_argument("command", choices=["install", "update"])
    parser.add_argument("--server")
    parser.add_argument("--client", choices=["codex", "claude", "both"])
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--wait-for-pid", type=int, help=argparse.SUPPRESS)
    try:
        args = parser.parse_args()
        if args.wait_for_pid is not None:
            raise SystemExit(run_independent_update(args))
        print(json.dumps(execute_release(args)))
    except (ReleaseError, OSError) as error:
        print(
            str(error) if isinstance(error, ReleaseError) else "release_filesystem_error",
            file=sys.stderr,
        )
        raise SystemExit(2) from None


if __name__ == "__main__":
    main()
