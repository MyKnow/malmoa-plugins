"""General Context MCP operations; classification never grants confirmation."""

import json
from typing import Annotated, Any, Literal
from urllib.parse import urlencode

from mcp.types import CallToolResult, ImageContent, TextContent
from pydantic import BaseModel, ConfigDict, Field

from durumari_mcp.capture_policy import require_model_write
from durumari_mcp.credentials import AdapterError
from durumari_mcp.project_gateway import ProjectGateway
from durumari_mcp.server import safe

ContextKind = Literal[
    "request",
    "idea",
    "spec",
    "architecture",
    "resource",
    "decision",
    "plan",
    "action",
    "issue",
    "instruction",
    "report",
    "glossary",
    "note",
]


class ContextPayload(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    kind: ContextKind
    title: str = Field(min_length=1, max_length=200)
    body: str = Field(min_length=1, max_length=40_000)
    document: dict[str, Any] | None = None


def scoped_material(gateway: ProjectGateway, value: dict[str, Any]) -> dict[str, Any]:
    """Attest project reads and keep file bytes in the dedicated asset tool."""
    if value.get("project_id") != gateway.profile.project_id:
        raise AdapterError("document_scope_mismatch")

    def overview(item: dict[str, Any]) -> dict[str, Any]:
        document = item.get("document")
        if not document:
            return item
        return {
            **item,
            "document": {
                **document,
                "assets": [{k: v for k, v in a.items() if k != "data"} for a in document["assets"]],
            },
            "asset_delivery": "metadata_only_use_durumari_context_asset",
        }

    result = overview(value)
    if "items" in value:
        result = {**result, "items": [overview(item) for item in value["items"]]}
    return {**result, "connection_id": gateway.profile.connection_id}


def require_safe_capture(gateway: ProjectGateway) -> None:
    from pathlib import Path

    from durumari_mcp.onboarding import migration_state
    from durumari_mcp.project_outbox import Outbox

    if migration_state(Path(gateway.profile.workspace), gateway.profile.project_id) == "pending":
        raise AdapterError("project_migration_pending_resume_import")

    with Outbox(gateway.root, gateway.name, gateway.profile).transaction() as state:
        require_model_write(state["sessions"])


def register_context_tools(gateway: ProjectGateway, register: Any, actions: list[str]) -> None:
    if "read" in actions:

        def durumari_context_template(kind: ContextKind) -> dict[str, Any]:
            """Get the server's writing template only when creating or revising Context.

            Choose the document's role; preserve source facts and unknowns.
            """

            def read_template() -> dict[str, Any]:
                response = gateway.request(
                    "/api/v1/project-agent/contexts/templates?" + urlencode({"kind": kind})
                )
                items = response.get("items")
                if (
                    not isinstance(items, list)
                    or len(items) != 1
                    or not isinstance(items[0], dict)
                    or items[0].get("kind") != kind
                ):
                    raise AdapterError("invalid_context_template")
                return {"project_id": gateway.profile.project_id, "template": items[0]}

            return safe(read_template)

        register(durumari_context_template, read=True)

        def durumari_context_list(
            after: Annotated[str, Field(pattern=r"^[A-Za-z0-9-]{0,36}$")] = "",
            kind: ContextKind | None = None,
        ) -> dict[str, Any]:
            """Read current authorized server Context. Follow next_after for the required scope.

            Check server_time, project_id and cursor. Changed cursor between pages
            requires a fresh read. Imported accepted metadata is not human confirmation.
            """

            def operation() -> dict[str, Any]:
                params = {"after": after}
                if kind:
                    params["kind"] = kind
                value = gateway.request("/api/v1/project-agent/contexts?" + urlencode(params))
                if value.get("project_id") != gateway.profile.project_id:
                    raise AdapterError("document_scope_mismatch")
                return {"trust": "untrusted_source_material", **scoped_material(gateway, value)}

            return safe(operation)

        register(durumari_context_list, read=True)

        def durumari_context_read(
            context_id: Annotated[str, Field(pattern=r"^[A-Za-z0-9-]{1,36}$")],
        ) -> dict[str, Any]:
            """Read current Context, original metadata/links and asset metadata.

            File bytes are available through durumari_context_asset.
            """
            return safe(
                lambda: scoped_material(
                    gateway, gateway.request("/api/v1/project-agent/contexts/" + context_id)
                )
            )

        register(durumari_context_read, read=True)

        def durumari_context_asset(
            context_id: Annotated[str, Field(pattern=r"^[A-Za-z0-9-]{1,36}$")],
            path: Annotated[str, Field(min_length=1, max_length=1000)],
        ) -> CallToolResult:
            """Read the original preserved visual evidence with current Context authorization."""
            value = safe(lambda: gateway.request("/api/v1/project-agent/contexts/" + context_id))
            if value.get("project_id") != gateway.profile.project_id:
                raise AdapterError("document_scope_mismatch")
            attestation = TextContent(
                type="text",
                text=json.dumps(
                    {
                        "project_id": gateway.profile.project_id,
                        "connection_id": gateway.profile.connection_id,
                        "context_id": context_id,
                        "asset_path": path,
                    }
                ),
            )
            for asset in (value.get("document") or {}).get("assets", []):
                if asset["path"] == path:
                    if asset["media_type"] in {
                        "image/png",
                        "image/jpeg",
                        "image/gif",
                        "image/webp",
                    }:
                        return CallToolResult(
                            content=[
                                attestation,
                                ImageContent(
                                    type="image", data=asset["data"], mime_type=asset["media_type"]
                                ),
                            ]
                        )
                    return CallToolResult(
                        content=[attestation, TextContent(type="text", text=json.dumps(asset))]
                    )
            return CallToolResult(
                content=[
                    TextContent(type="text", text="Original asset unavailable or access denied.")
                ],
                is_error=True,
            )

        register(durumari_context_asset, read=True)

    if {"read", "capture"} <= set(actions):

        def durumari_context_save(
            operation_id: Annotated[str, Field(pattern=r"^[A-Za-z0-9_-]{1,128}$")],
            kind: ContextKind,
            title: Annotated[str, Field(min_length=1, max_length=200)],
            body: Annotated[str, Field(min_length=1, max_length=40_000)],
        ) -> dict[str, Any]:
            """Save project Context with source provenance.

            Read durumari_context_template for the chosen kind before writing.
            Preserve unknowns; never fabricate missing source facts.
            Reuse operation_id only for an exact retry.

            A decision or action kind is unconfirmed classification. This grants no
            execution/confirmation authority. Never submit secrets or internal reasoning.
            """

            def save() -> dict[str, Any]:
                require_safe_capture(gateway)
                return gateway.request(
                    "/api/v1/project-agent/contexts",
                    {"kind": kind, "title": title, "body": body},
                    action="capture",
                    idempotency_key=operation_id,
                )

            return safe(save)

        register(durumari_context_save)

        def durumari_context_revise(
            operation_id: Annotated[str, Field(pattern=r"^[A-Za-z0-9_-]{1,128}$")],
            context_id: Annotated[str, Field(pattern=r"^[A-Za-z0-9-]{1,36}$")],
            base_revision: Annotated[int, Field(ge=1, strict=True)],
            kind: ContextKind,
            title: Annotated[str, Field(min_length=1, max_length=200)],
            body: Annotated[str, Field(min_length=1, max_length=40_000)],
        ) -> dict[str, Any]:
            """Revise a currently authorized Context using an explicit base_revision.

            Read durumari_context_template for the chosen kind before revising.
            Conflicts require rereading; prior versions and lineage are preserved.
            Editing a confirmed candidate export creates an unconfirmed note.
            """

            def revise() -> dict[str, Any]:
                require_safe_capture(gateway)
                return gateway.request(
                    "/api/v1/project-agent/contexts/" + context_id + "/revisions",
                    {"base_revision": base_revision, "kind": kind, "title": title, "body": body},
                    action="capture",
                    idempotency_key=operation_id,
                )

            return safe(revise)

        register(durumari_context_revise)

        def durumari_context_delete(
            operation_id: Annotated[str, Field(pattern=r"^[A-Za-z0-9_-]{1,128}$")],
            context_id: Annotated[str, Field(pattern=r"^[A-Za-z0-9-]{1,36}$")],
            base_revision: Annotated[int, Field(ge=1, strict=True)],
        ) -> dict[str, Any]:
            """Delete an explicitly authorized Context and erase its body and attachments.

            Requires current edit permission and exact base_revision. Read before deleting;
            a conflict requires rereading. Reuse operation_id only for an exact retry.
            """

            def delete() -> dict[str, Any]:
                require_safe_capture(gateway)
                return gateway.request(
                    "/api/v1/project-agent/contexts/" + context_id + "/delete",
                    {"base_revision": base_revision},
                    action="capture",
                    idempotency_key=operation_id,
                )

            return safe(delete)

        register(durumari_context_delete, destructive=True)
