"""Capture admission and content-free diagnostics shared by all model write paths."""

from typing import Any

from durumari_mcp.credentials import AdapterError

QUARANTINE_REASONS = frozenset({
    "sensitive_operation_detected",
    "sensitive_content_detected",
    "unattested_context_read_quarantined",
    "related_session_quarantined",
    "legacy_quarantine_reason_unknown",
})


def quarantine_reasons(session: dict[str, Any]) -> list[str]:
    if not session.get("quarantined"):
        return []
    # Never echo arbitrary state strings, tool arguments or source text in status.
    reasons = QUARANTINE_REASONS.intersection(session.get("omissions", []))
    return sorted(reasons or {"legacy_quarantine_reason_unknown"})


def related_sessions(
    sessions: dict[str, Any], session_id: str,
) -> dict[str, Any]:
    """Resolve only host-observed parent links; pending is never copied as taint."""
    neighbors: dict[str, set[str]] = {}
    for identifier, session in sessions.items():
        parent = session.get("parent_session_id")
        if isinstance(parent, str):
            neighbors.setdefault(identifier, set()).add(parent)
            neighbors.setdefault(parent, set()).add(identifier)
    family: set[str] = set()
    remaining = [session_id]
    while remaining:
        current = remaining.pop()
        if current not in family:
            family.add(current)
            remaining.extend(neighbors.get(current, set()) - family)
    return {identifier: sessions[identifier] for identifier in family if identifier in sessions}


def capture_write_status(sessions: dict[str, Any]) -> dict[str, Any]:
    quarantined = [s for s in sessions.values() if s.get("quarantined")]
    pending = sum(bool(s.get("context_read_pending")) for s in sessions.values())
    pending_unknown = any(
        s.get("context_read_pending") and (
            "pending_read_ids" not in s
            or "legacy_unattributed_read" in s["pending_read_ids"]
        ) for s in sessions.values()
    )
    return {
        "state": "quarantined" if quarantined else "pending_read" if pending else "ready",
        "quarantined_sessions": len(quarantined),
        "pending_read_sessions": pending,
        "pending_read_identity_unknown": pending_unknown,
        "reasons": sorted({reason for s in quarantined for reason in quarantine_reasons(s)}),
        "recovery": (
            "review_required_no_automatic_reset" if quarantined or pending_unknown
            else "await_same_connection_read_receipt" if pending else "none"
        ),
    }


def require_model_write(sessions: dict[str, Any]) -> None:
    # MCP callers cannot attest their host session identity. Keep profile-wide
    # admission until a trusted host binding exists; model-supplied IDs cannot relax it.
    status = capture_write_status(sessions)
    if status["quarantined_sessions"]:
        raise AdapterError("sensitive_profile_requires_host_capture")
    if status["pending_read_sessions"]:
        raise AdapterError("project_context_read_pending")
