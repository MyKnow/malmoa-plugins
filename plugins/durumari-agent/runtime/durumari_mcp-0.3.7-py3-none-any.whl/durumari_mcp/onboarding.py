"""Repository bootstrap and portable, reviewed document migration."""

import base64
import hashlib
import json
import mimetypes
import os
import re
import shlex
import subprocess
import sys
import tempfile
import tomllib
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlsplit

import yaml

from durumari_mcp.capture import contains_sensitive
from durumari_mcp.credentials import AdapterError, profile_name
from durumari_mcp.legacy import (
    DIRECTORY_V1,
    MANAGED_END_V1,
    MANAGED_START_V1,
    MODULE_V1,
    binding,
    canonical_binding,
    canonical_hooks,
    data_directory,
    manifest_path,
)
from durumari_mcp.project_credentials import ProjectProfile

KINDS = [
    "request",
    "idea",
    "spec",
    "architecture",
    "resource",
    "decision",
    "plan",
    "action",
    "issue",
    "instruction",
    "report",
    "glossary",
    "note",
]
LABELS = dict(
    zip(
        KINDS,
        [
            "요청",
            "아이디어",
            "명세",
            "아키텍처",
            "자원",
            "결정",
            "계획",
            "할 일",
            "쟁점",
            "작업 지침",
            "결과 보고",
            "용어사전",
            "일반 기록",
        ],
        strict=True,
    )
)
START, END = "<!-- DURUMARI MANAGED BEGIN -->", "<!-- DURUMARI MANAGED END -->"
MAX_ASSET = 524_288
SOURCE_CODE_SUFFIXES = {
    ".arb",
    ".cjs",
    ".mjs",
    ".py",
    ".dart",
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
    ".sh",
    ".ps1",
    ".toml",
    ".yaml",
    ".yml",
    ".json",
}
LINK = re.compile(r"!?\[[^\]]*\]\((<[^>]+>|[^\s)]+)(?:\s+[^)]*)?\)")
EXCLUDED = {".git", ".venv", "node_modules", ".env", ".durumari", DIRECTORY_V1, "__pycache__"}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def inside(root: Path, path: Path) -> Path:
    if path.is_symlink() or any(
        parent.is_symlink() for parent in path.parents if parent != root and root in parent.parents
    ):
        raise AdapterError("symlink_not_imported")
    try:
        path.resolve().relative_to(root.resolve())
    except ValueError:
        raise AdapterError("path_out_of_workspace") from None
    return path


def read_manifest(root: Path) -> dict[str, Any]:
    """Validate public binding metadata without granting repository access.

    Only local diagnostics and human-approved connect may use this reader.
    All Context and capture entrypoints must use load_manifest/check_binding.
    """
    try:
        path = inside(root, manifest_path(root))
        value = yaml.safe_load(path.read_text(encoding="utf-8"))
        if (
            not isinstance(value, dict)
            or set(value) - {"repository_id"}
            != {"schema_version", "server", "project_id", "source_id", "context_source"}
            or type(value["schema_version"]) is not int
            or value["schema_version"] != 1
            or value["context_source"] != "server"
        ):
            raise ValueError
        ProjectProfile.origin(value["server"])
        for key in ("project_id", "source_id"):
            if not isinstance(value[key], str) or not re.fullmatch(
                r"[A-Za-z0-9-]{1,128}", value[key]
            ):
                raise ValueError
        if "repository_id" in value and (
            not isinstance(value["repository_id"], str)
            or not re.fullmatch(r"[0-9a-f]{64}", value["repository_id"])
        ):
            raise ValueError
        return value
    except (OSError, ValueError, TypeError, yaml.YAMLError):
        raise AdapterError("invalid_project_manifest") from None


def load_manifest(root: Path) -> dict[str, Any]:
    value = read_manifest(root)
    if "repository_id" in value and value["repository_id"] != repository_identity(root):
        raise AdapterError("project_repository_mismatch_reconnect")
    return value


def repository_diagnostics(root: Path) -> dict[str, Any]:
    manifest = read_manifest(root)
    current = repository_identity(root)
    matches = manifest.get("repository_id", current) == current
    return {
        "project_id": manifest["project_id"],
        "server": manifest["server"],
        "repository_matches": matches,
        "bound_repository_id": manifest.get("repository_id"),
        "current_repository_id": current,
        "ready": False,
        "reason": (
            "live_access_not_verified" if matches else "project_repository_mismatch_reconnect"
        ),
        "scope": "local_diagnostics_only",
        "context_available": False,
        "capture_paused": not matches,
        "pending_records": "preserved_not_inspected",
        "next_action": "verify_live_access" if matches else "browser_reconnect_then_reload_host",
    }


def repository_identity(root: Path) -> str:
    """Bind copied manifests to a repository, while allowing clones/worktrees.

    Store only a hash of a credential-free remote or a local repository path.
    Multiple repositories can still explicitly enroll in the same server project.
    """

    def git(*args: str) -> str:
        return subprocess.check_output(
            ["git", "-C", str(root), *args], stderr=subprocess.DEVNULL, text=True
        ).strip()

    try:
        remote = git("config", "--get", "remote.origin.url")
        if "://" in remote:
            parsed = urlsplit(remote)
            identity = (
                (parsed.hostname or "")
                + (":" + str(parsed.port) if parsed.port else "")
                + parsed.path
            )
        else:
            identity = remote.split("@", 1)[-1].replace(":", "/", 1)
        identity = "remote:" + identity.rstrip("/").removesuffix(".git")
    except (subprocess.CalledProcessError, OSError, ValueError):
        try:
            identity = "local:" + str((root / git("rev-parse", "--git-common-dir")).resolve())
        except (subprocess.CalledProcessError, OSError):
            identity = "local:" + str(root.resolve())
    return digest(identity.encode())


def profile_for(project: str, client: str, root: Path) -> str:
    identity = project + "\0" + str(root.resolve())
    return "durumari-" + digest(identity.encode())[:16] + "-" + client


def managed(previous: str, block: str) -> str:
    previous = previous.replace(MANAGED_START_V1, START).replace(MANAGED_END_V1, END)
    if START in previous or END in previous:
        if (
            previous.count(START) != 1
            or previous.count(END) != 1
            or previous.index(START) > previous.index(END)
        ):
            raise AdapterError("invalid_managed_instructions")
        return (
            previous[: previous.index(START)] + block + previous[previous.index(END) + len(END) :]
        )
    return previous.rstrip() + "\n\n" + block + "\n"


def _codex_interrupt_timeout(hook: dict[str, Any], event: str) -> bool:
    return (
        event == "Interrupt"
        and "commandWindows" in hook
        and "-m durumari_mcp project-hook " in str(hook.get("command", ""))
        and type(hook.get("timeout")) in {int, float}
        and hook["timeout"] > 3
    )


def _hook_execution(group: Any, event: str) -> Any:
    """Compare execution definitions without labels or host enablement flags."""
    if not isinstance(group, dict) or not isinstance(group.get("hooks"), list):
        return group
    result = {key: value for key, value in group.items() if key not in {"enabled", "disabled"}}
    result["hooks"] = [
        {
            key: value
            for key, value in hook.items()
            if key not in {"statusMessage", "enabled", "disabled"}
        }
        if isinstance(hook, dict)
        else hook
        for hook in group["hooks"]
    ]
    for hook in result["hooks"]:
        if isinstance(hook, dict) and _codex_interrupt_timeout(hook, event):
            hook["timeout"] = 3  # Codex already applies this deadline to older definitions.
    return result


def merge_hooks(current: dict[str, Any], hooks: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = json.loads(json.dumps(current))
    existing = result.setdefault("hooks", {})
    if not isinstance(existing, dict):
        raise AdapterError("invalid_existing_hooks")
    for event, groups in hooks["hooks"].items():
        old = existing.setdefault(event, [])
        if not isinstance(old, list):
            raise AdapterError("invalid_existing_hooks")
        for group in groups:
            match = next(
                (
                    item
                    for item in old
                    if _hook_execution(item, event) == _hook_execution(group, event)
                ),
                None,
            )
            if match is None:
                old.append(json.loads(json.dumps(group)))
                continue
            for previous, incoming in zip(match["hooks"], group["hooks"], strict=True):
                if incoming.get("timeout") == 3 and _codex_interrupt_timeout(previous, event):
                    previous["timeout"] = 3
                label = previous.get("statusMessage")
                if (label is None or isinstance(label, str) and not label.strip()) and incoming.get(
                    "statusMessage"
                ):
                    previous["statusMessage"] = incoming["statusMessage"]
    return result


def init_project(
    root: Path,
    server: str,
    project: str,
    source: str,
    clients: list[str],
    *,
    apply: bool,
    for_migration: bool = False,
    preserve_disabled_hooks: bool = False,
    profile_names: dict[str, str] | None = None,
    instruction_block: str | None = None,
    approved_rebind: dict[str, Any] | None = None,
    previous_profile_names: dict[str, str] | None = None,
) -> dict[str, Any]:
    root = root.resolve(strict=True)
    server = ProjectProfile.origin(server)
    if (
        not re.fullmatch(r"[A-Za-z0-9-]{1,128}", project)
        or not re.fullmatch(r"[A-Za-z0-9-]{1,128}", source)
        or not clients
        or any(c not in {"codex", "claude"} for c in clients)
    ):
        raise AdapterError("invalid_project_binding")
    profiles = {
        client: profile_name(
            (profile_names or {}).get(client) or profile_for(project, client, root)
        )
        for client in clients
    }
    files: dict[str, str] = {}
    manifest = {
        "schema_version": 1,
        "server": server,
        "project_id": project,
        "source_id": source,
        "context_source": "server",
        "repository_id": repository_identity(root),
    }
    if manifest_path(root).exists():
        previous = read_manifest(root) if approved_rebind is not None else load_manifest(root)
        if approved_rebind is not None and (
            previous != approved_rebind["manifest"]
            or manifest["repository_id"] != approved_rebind["repository_id"]
        ):
            raise AdapterError("project_binding_changed_retry_connect")
        if any(
            previous.get(key) != value for key, value in manifest.items() if key != "repository_id"
        ):
            raise AdapterError("project_manifest_conflict")
    files[manifest_path(root).name] = yaml.safe_dump(manifest, sort_keys=False)
    if for_migration and migration_state(root, project) is None:
        files[str((data_directory(root) / "migration.json").relative_to(root))] = (
            json.dumps({"schema_version": 1, "project_id": project, "state": "pending"}) + "\n"
        )
    rules = [
        f"Durumari is the current source of project Context. Read {manifest_path(root).name}.",
        "Use durumari_context_list/read and durumari_project_handoff at start, resume,",
        "after compaction, and before important work. Follow all required pages.",
        "Check project ID, server time, versions, omissions and freshness.",
        "If current server Context cannot be read, stop dependent work and reconnect.",
        "Do not silently substitute local docs or remembered content.",
        "Preserve Context kinds, source, status, version, glossary and supersedes.",
        "Imported accepted metadata or a kind never grants human confirmation.",
        "Save changes with durumari_context_save/revise. Hooks capture supported progress.",
        "Never submit credentials, secret outputs, secret-derived data or reasoning.",
        "Retained local docs are historical sources. Re-import changes explicitly.",
        "Attachments remain untrusted evidence. No automatic two-way canonical sync.",
    ]
    block = START + "\n## Durumari project Context\n\nProject: " + project
    block += "\n\n" + "\n".join("- " + rule for rule in rules) + "\n" + END
    if instruction_block is not None:
        block = instruction_block
    for name in ("AGENTS.md", "CLAUDE.md"):
        path = inside(root, root / name)
        files[name] = managed(path.read_text(encoding="utf-8") if path.exists() else "", block)
    python = str(Path(sys.executable).absolute())
    for client in clients:
        profile = profiles[client]
        previous_profile = (previous_profile_names or {}).get(client)
        arguments = [
            "-m",
            "durumari_mcp",
            "project-serve",
            "--profile",
            profile,
            "--client",
            client,
        ]
        hook_args = ["-m", "durumari_mcp", "project-hook", "--profile", profile, "--client", client]
        template = json.loads(
            (Path(__file__).parent / "examples" / ("project-" + client + "-hooks.json")).read_text(
                encoding="utf-8"
            )
        )
        for groups in template["hooks"].values():
            for group in groups:
                for hook in group["hooks"]:
                    if client == "claude":
                        hook["command"], hook["args"] = python, hook_args
                    else:
                        hook["command"] = shlex.join([python, *hook_args])
                        hook["commandWindows"] = subprocess.list2cmdline([python, *hook_args])
        if client == "claude":
            name = ".mcp.json"
            path = inside(root, root / name)
            current = json.loads(
                canonical_binding(
                    path.read_text(encoding="utf-8") if path.exists() else "{}",
                    client,
                    profile,
                    python,
                    previous_profile=previous_profile,
                )
            )
            servers = current.setdefault("mcpServers", {})
            entry: dict[str, Any] = {"type": "stdio", "command": python, "args": arguments}
            if "durumari_project" in servers and servers["durumari_project"] != entry:
                raise AdapterError("existing_mcp_binding_conflict")
            servers["durumari_project"] = entry
            files[name] = json.dumps(current, ensure_ascii=False, indent=2) + "\n"
            name = ".claude/settings.local.json"
            path = inside(root, root / name)
            current = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
            files[name] = (
                json.dumps(
                    merge_hooks(
                        canonical_hooks(
                            current, client, profile, python, previous_profile=previous_profile
                        ),
                        template,
                    ),
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n"
            )
        else:
            name = ".codex/config.toml"
            path = inside(root, root / name)
            current = canonical_binding(
                path.read_text(encoding="utf-8") if path.exists() else "",
                client,
                profile,
                python,
                previous_profile=previous_profile,
            )
            parsed = tomllib.loads(current)
            entry = {"command": python, "args": arguments, "startup_timeout_sec": 30}
            old = parsed.get("mcp_servers", {}).get("durumari_project")
            if old is not None and old != entry:
                raise AdapterError("existing_mcp_binding_conflict")
            if not old:
                current += (
                    "\n[mcp_servers.durumari_project]\ncommand = "
                    + json.dumps(python)
                    + "\nargs = "
                    + json.dumps(arguments)
                    + "\nstartup_timeout_sec = 30\n"
                )
            keep_disabled = (
                preserve_disabled_hooks and parsed.get("features", {}).get("hooks") is False
            )
            if parsed.get("features", {}).get("hooks") is not True and not keep_disabled:
                if "[features]" in current:
                    current = re.sub(
                        r"(?m)^(hooks\s*=\s*)false(?=\s*(?:#|$))", r"\g<1>true", current
                    )
                    if "hooks" not in parsed.get("features", {}):
                        current = current.replace("[features]", "[features]\nhooks = true", 1)
                else:
                    current += "\n[features]\nhooks = true\n"
            if (
                not keep_disabled
                and tomllib.loads(current).get("features", {}).get("hooks") is not True
            ):
                raise AdapterError("existing_hooks_configuration_requires_review")
            files[name] = current
            name = ".codex/hooks.json"
            path = inside(root, root / name)
            current = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
            files[name] = (
                json.dumps(
                    merge_hooks(
                        canonical_hooks(
                            current, client, profile, python, previous_profile=previous_profile
                        ),
                        template,
                    ),
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n"
            )
    result = {
        "project_id": project,
        "profiles": profiles,
        "files": list(files),
        "applied": False,
    }
    ignore_path = inside(root, root / ".gitignore")
    ignores = ignore_path.read_text(encoding="utf-8") if ignore_path.exists() else ""
    patterns = [
        "/.codex/config.toml",
        "/.codex/hooks.json",
        "/.mcp.json",
        "/.claude/settings.local.json",
        "*.durumari-backup-*",
        "/.durumari/",
    ]
    missing = [p for p in patterns if p not in ignores.splitlines()]
    if missing:
        files[".gitignore"] = (
            ignores.rstrip() + "\n\n# Durumari local host settings\n" + "\n".join(missing) + "\n"
        )
        result["files"] = list(files)
    # Validate everything before the first write; repeated setup is idempotent.
    for name in files:
        inside(root, root / name)
    if apply:
        for name, content in files.items():
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists() or path.read_text(encoding="utf-8") != content:
                if path.exists():
                    backup = path.with_name(
                        path.name + ".durumari-backup-" + digest(path.read_bytes())[:12]
                    )
                    inside(root, backup)
                    if not backup.exists():
                        with backup.open("xb") as stream:
                            stream.write(path.read_bytes())
                fd, temporary_name = tempfile.mkstemp(prefix=".durumari-", dir=path.parent)
                temporary = Path(temporary_name)
                try:
                    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                        stream.write(content)
                        stream.flush()
                        os.fsync(stream.fileno())
                    os.replace(temporary, path)
                finally:
                    temporary.unlink(missing_ok=True)
        result["applied"] = True
    return result


def contains_sensitive_migration(value: Any) -> bool:
    """Allow only closed Markdown code examples, without changing capture policy."""
    example = re.compile(r"`Authorization: Plugin(?: <plugin_token>)?`", re.IGNORECASE)

    def examples_only(item: Any, depth: int = 0) -> Any:
        if depth > 32:
            return item
        if isinstance(item, str):
            text = example.sub("`plugin authorization header example`", item)
            return re.sub(
                r"\bauthorization:(?=\r?\n\r?\n1\. )",
                "authorization procedure:",
                text,
                flags=re.IGNORECASE,
            )
        if isinstance(item, dict):
            return {k: examples_only(v, depth + 1) for k, v in item.items()}
        if isinstance(item, list):
            return [examples_only(v, depth + 1) for v in item]
        return item

    return contains_sensitive(examples_only(value))


def scan_project(
    root: Path,
    paths: list[str],
    *,
    include_resources: bool = False,
    reference_source_code: bool = False,
) -> dict[str, Any]:
    root = root.resolve(strict=True)
    selected: set[Path] = set()
    omissions: list[dict[str, str]] = []
    for value in paths:
        target = inside(root, root / value)
        if not target.exists():
            omissions.append({"path": value, "reason": "missing_source"})
            continue
        selected.update(
            (p for p in target.rglob("*") if p.is_file())
            if target.is_dir() and include_resources
            else target.rglob("*.md")
            if target.is_dir()
            else [target]
        )
    indexes = {}
    for value in paths:
        target = root / value
        if target.is_dir():
            for index in target.rglob("index.json"):
                inside(root, index)
                try:
                    data = json.loads(index.read_text(encoding="utf-8"))
                    for entries in data.values():
                        if isinstance(entries, list):
                            for entry in entries:
                                if isinstance(entry, dict) and "id" in entry and "path" in entry:
                                    indexes[entry["id"]] = entry["path"]
                except (OSError, ValueError):
                    omissions.append(
                        {"path": str(index.relative_to(root)), "reason": "invalid_index"}
                    )
    documents: list[dict[str, Any]] = []
    for path in sorted(selected):
        relative = str(path.relative_to(root)).replace(os.sep, "/")
        if any(
            part in EXCLUDED or part.startswith(".env") for part in path.relative_to(root).parts
        ):
            omissions.append({"path": relative, "reason": "excluded_sensitive_or_runtime"})
            continue
        inside(root, path)
        raw = path.read_bytes()
        if path.suffix.lower() != ".md" and include_resources:
            if len(raw) > MAX_ASSET:
                omissions.append({"path": relative, "reason": "attachment_size_limit"})
                continue
            if contains_sensitive(raw.decode("utf-8", errors="ignore")):
                raise AdapterError("sensitive_attachment_excluded")
            body = "Original project resource: " + relative
            documents.append(
                {
                    "kind": "resource",
                    "title": path.name[:200],
                    "body": body,
                    "document": {
                        "raw": body,
                        "path": relative,
                        "sha256": digest(body.encode()),
                        "metadata": {
                            "_migration": {
                                "current": None,
                                "classification": "resource_file",
                                "human_confirmation": "not_imported",
                                "original_sha256": digest(raw),
                            }
                        },
                        "links": [],
                        "assets": [
                            {
                                "path": relative,
                                "media_type": mimetypes.guess_type(relative)[0]
                                or "application/octet-stream",
                                "sha256": digest(raw),
                                "data": base64.b64encode(raw).decode(),
                            }
                        ],
                    },
                }
            )
            continue
        if len(raw) > 80_000:
            omissions.append({"path": relative, "reason": "document_size_limit"})
            continue
        try:
            text = raw.decode("utf-8")
        except UnicodeError:
            omissions.append({"path": relative, "reason": "unsupported_encoding"})
            continue
        if len(text) > 40_000:
            omissions.append({"path": relative, "reason": "document_size_limit"})
            continue
        if contains_sensitive_migration(text):
            raise AdapterError("sensitive_document_excluded")
        metadata: dict[str, Any] = {}
        if re.match(r"\A---\r?\n", text):
            front = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|\Z)", text, re.DOTALL)
            if not front:
                raise AdapterError("invalid_document_frontmatter")
            try:
                metadata = yaml.safe_load(front[1]) or {}
            except yaml.YAMLError:
                raise AdapterError("invalid_document_frontmatter") from None
            if not isinstance(metadata, dict):
                raise AdapterError("invalid_document_frontmatter")
        metadata = json.loads(json.dumps(metadata, default=str))
        identifier = metadata.get("id") or metadata.get("request_id")
        if identifier is not None and not isinstance(identifier, str):
            raise AdapterError("invalid_document_identifier")
        explicit = metadata.get("kind")
        prefix = str(identifier).split("-", 1)[0]
        kind = (
            explicit
            if explicit in KINDS
            else prefix
            if prefix in KINDS
            else "instruction"
            if path.name.upper() in {"AGENTS.MD", "CLAUDE.MD"}
            else "resource"
            if path.stem == "team"
            else "plan"
            if "plans" in path.parts
            else "instruction"
            if "templates" in path.parts
            or path.stem in {"spec", "request", "architecture", "decision", "idea"}
            else "note"
        )
        metadata["_migration"] = {
            "current": indexes.get(identifier) == relative if identifier in indexes else None,
            "classification": "metadata" if explicit in KINDS or prefix in KINDS else "path_hint",
            "human_confirmation": "not_imported",
        }
        links: list[str] = []
        assets = []
        asset_paths = set()
        for match in LINK.finditer(text):
            link_target = unquote(match[1].strip("<>"))
            parsed = urlsplit(link_target)
            if "templates" in path.parts and re.search(r"<(?:uuid|hash|topic|area)>", link_target):
                links.append(link_target)
                continue
            if parsed.scheme or parsed.netloc or not parsed.path:
                links.append(link_target)
                continue
            try:
                resolved = inside(root, path.parent / parsed.path).resolve()
                archive = str(resolved.relative_to(root)).replace(os.sep, "/")
            except (AdapterError, ValueError):
                omissions.append({"path": relative, "reason": "link_out_of_workspace"})
                continue
            links.append(archive + ("#" + parsed.fragment if parsed.fragment else ""))
            if not resolved.is_file():
                omissions.append({"path": archive, "reason": "missing_attachment_or_link"})
                continue
            if resolved.suffix.lower() == ".md" or archive in asset_paths:
                continue
            if (
                reference_source_code
                and resolved not in selected
                and resolved.suffix.lower() in SOURCE_CODE_SUFFIXES
            ):
                metadata["_migration"].setdefault("source_code_references", []).append(archive)
                continue
            if resolved.stat().st_size > MAX_ASSET:
                omissions.append({"path": archive, "reason": "attachment_size_limit"})
                continue
            content = resolved.read_bytes()
            if any(part.startswith(".env") for part in Path(archive).parts) or contains_sensitive(
                content.decode("utf-8", errors="ignore")
            ):
                raise AdapterError("sensitive_attachment_excluded")
            assets.append(
                {
                    "path": archive,
                    "media_type": mimetypes.guess_type(archive)[0] or "application/octet-stream",
                    "sha256": digest(content),
                    "data": base64.b64encode(content).decode(),
                }
            )
            asset_paths.add(archive)
        heading = re.search(r"^#\s+(.+)$", text, re.MULTILINE)
        title = str(metadata.get("title") or (heading[1] if heading else path.stem))[:200]
        source = {
            "raw": text,
            "path": relative,
            "sha256": digest(raw),
            "metadata": metadata,
            "links": links,
            "assets": assets,
        }
        if len(json.dumps(source).encode()) > 2_097_152:
            omissions.append({"path": relative, "reason": "combined_attachment_size_limit"})
            continue
        documents.append({"kind": kind, "title": title, "body": text, "document": source})
    versions: dict[str, list[dict[str, Any]]] = {}
    for document in documents:
        meta = document["document"]["metadata"]
        identifier = meta.get("id") or meta.get("request_id")
        if identifier:
            versions.setdefault(identifier, []).append(document)
    for identifier, rows in versions.items():
        if len(rows) > 1 and not any(
            r["document"]["metadata"]["_migration"]["current"] is True for r in rows
        ):
            omissions.append({"path": identifier, "reason": "ambiguous_current_version"})
    try:
        commit = subprocess.check_output(
            ["git", "-C", str(root), "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True
        ).strip()
        dirty = bool(
            subprocess.check_output(["git", "-C", str(root), "status", "--porcelain"], text=True)
        )
    except (OSError, subprocess.CalledProcessError):
        commit = None
        dirty = None
    return {
        "schema_version": 1,
        "base_commit": commit,
        "working_tree_dirty": dirty,
        "documents": documents,
        "omissions": omissions,
        "complete": not omissions,
    }


def configured_profile(root: Path, client: str) -> str | None:
    """Use the current local MCP binding after a connection is renewed."""
    name = ".codex/config.toml" if client == "codex" else ".mcp.json"
    path = inside(root, root / name)
    if not path.exists():
        return None
    try:
        data = (
            tomllib.loads(path.read_text(encoding="utf-8"))
            if client == "codex"
            else json.loads(path.read_text(encoding="utf-8"))
        )
        entry = binding(data.get("mcp_servers" if client == "codex" else "mcpServers", {}))
        if entry is None:
            return None
        args = entry["args"]
        if (
            not isinstance(args, list)
            or len(args) != 7
            or (
                args[:4] != ["-m", "durumari_mcp", "project-serve", "--profile"]
                and args[:4] != ["-m", MODULE_V1, "project-serve", "--profile"]
            )
            or args[5:] != ["--client", client]
            or not isinstance(args[4], str)
        ):
            raise ValueError
        return profile_name(args[4])
    except (OSError, ValueError, TypeError, KeyError, AttributeError, AdapterError):
        raise AdapterError("invalid_configured_profile") from None


def host_checks(root: Path, project: str, client: str, profile: str) -> dict[str, bool]:
    """Inspect effective generated bindings, not merely the presence of files."""
    checks: dict[str, bool] = {}
    checks["migration"] = migration_state(root, project) in {None, "verified", "partial_reviewed"}
    name = "AGENTS.md" if client == "codex" else "CLAUDE.md"
    try:
        rules = inside(root, root / name).read_text(encoding="utf-8")
        checks["managed_instructions"] = (
            rules.count(START) == rules.count(END) == 1 and "Project: " + project in rules
        )
    except (OSError, AdapterError):
        checks["managed_instructions"] = False
    args = ["-m", "durumari_mcp", "project-serve", "--profile", profile, "--client", client]
    try:
        if client == "codex":
            data = tomllib.loads(
                inside(root, root / ".codex/config.toml").read_text(encoding="utf-8")
            )
            entry = data["mcp_servers"]["durumari_project"]
            enabled = data.get("features", {}).get("hooks") is True
            hooks_path = ".codex/hooks.json"
        else:
            data = json.loads(inside(root, root / ".mcp.json").read_text(encoding="utf-8"))
            entry = data["mcpServers"]["durumari_project"]
            enabled = entry.get("type") == "stdio"
            hooks_path = ".claude/settings.local.json"
        command = entry["command"]
        checks["mcp_binding"] = (
            entry.get("args") == args and isinstance(command, str) and Path(command).is_file()
        )
        hooks = json.loads(inside(root, root / hooks_path).read_text(encoding="utf-8"))["hooks"]
        expected = ["-m", "durumari_mcp", "project-hook", "--profile", profile, "--client", client]
        for event in (
            "SessionStart",
            "UserPromptSubmit",
            "PreToolUse",
            "PostToolUse",
            "SessionEnd",
        ):
            matches = []
            for group in hooks.get(event, []):
                for hook in group.get("hooks", []):
                    matches.append(
                        hook.get("command") == command and hook.get("args") == expected
                        if client == "claude"
                        else hook.get("command") == shlex.join([command, *expected])
                    )
            checks[event] = enabled and any(matches)
    except (OSError, AdapterError, ValueError, KeyError, TypeError, AttributeError):
        checks["mcp_binding"] = False
        checks["hooks"] = False
    return checks


def migration_state(root: Path, project: str) -> str | None:
    path = inside(root, data_directory(root) / "migration.json")
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if (
            value.get("schema_version") != 1
            or value.get("project_id") != project
            or value.get("state") not in {"pending", "verified", "partial_reviewed"}
        ):
            raise ValueError
        return str(value["state"])
    except (OSError, ValueError, TypeError, AttributeError):
        raise AdapterError("invalid_migration_state") from None


def record_migration(root: Path, project: str, state: str) -> None:
    path = inside(root, data_directory(root) / "migration.json")
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".migration-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump({"schema_version": 1, "project_id": project, "state": state}, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)
