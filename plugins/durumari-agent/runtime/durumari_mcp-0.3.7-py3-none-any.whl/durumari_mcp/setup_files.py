"""Validate server-generated, secret-free setup before changing local files."""

import hashlib
from typing import Any

import yaml

from durumari_mcp.credentials import AdapterError


def server_instructions(value: dict[str, Any], origin: str, project: str, source: str) -> str:
    try:
        if (
            value["schema_version"] != 1
            or (value["server"], value["project_id"], value["source_id"])
            != (origin, project, source)
            or set(value["files"]) != {"durumari.yaml", "AGENTS.md"}
            or set(value["sha256"]) != set(value["files"])
        ):
            raise ValueError
        for name, body in value["files"].items():
            if (
                not isinstance(body, str)
                or len(body.encode("utf-8")) > 16384
                or hashlib.sha256(body.encode("utf-8")).hexdigest() != value["sha256"][name]
            ):
                raise ValueError
        manifest = yaml.safe_load(value["files"]["durumari.yaml"])
        if manifest != {
            "schema_version": 1,
            "server": origin,
            "project_id": project,
            "source_id": source,
            "context_source": "server",
        }:
            raise ValueError
        block = value["files"]["AGENTS.md"]
        if (
            not block.startswith("<!-- DURUMARI MANAGED BEGIN -->\n")
            or not block.endswith("<!-- DURUMARI MANAGED END -->")
            or block.count("<!-- DURUMARI MANAGED BEGIN -->") != 1
            or block.count("<!-- DURUMARI MANAGED END -->") != 1
            or f"Project: {project}\n" not in block
        ):
            raise ValueError
        return str(block)
    except (KeyError, TypeError, ValueError, yaml.YAMLError):
        raise AdapterError("invalid_server_setup_files") from None
