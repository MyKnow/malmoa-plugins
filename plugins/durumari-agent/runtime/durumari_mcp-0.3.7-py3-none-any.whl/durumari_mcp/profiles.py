"""Host-only metadata bridge; never a model-callable MCP tool or a credential store.

The embedding application's authenticated POST callback supplies its existing
user-session transport. Do not forward that session into the stdio adapter.
After resolving, explicitly choose an alias and pass ``secret_pin`` to the
normal connection approval UI. Its recent proof and individual secret policy
remain mandatory; this helper issues no grant and never consumes one.
"""

from collections.abc import Callable
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from durumari_mcp.credentials import AdapterError

Purpose = Literal["metadata", "reveal", "use_tool", "use_model"]
Provider = Literal["local", "openai", "anthropic"]
AuthenticatedPost = Callable[[str, dict[str, Any]], object]


class StrictMetadata(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True, hide_input_in_errors=True)


class SecretReference(StrictMetadata):
    alias: str = Field(pattern=r"^[A-Z][A-Z0-9_]{0,63}$")
    secret_id: str = Field(pattern=r"^[A-Za-z0-9_-]{1,36}$")
    revision: int = Field(ge=1)
    policy_revision: int = Field(ge=1)

    def secret_pin(self) -> dict[str, str | int]:
        """Input for explicit existing connection approval, not a use authorization."""
        return {
            "id": self.secret_id,
            "revision": self.revision,
            "policy_revision": self.policy_revision,
        }


class ResolvedProfile(StrictMetadata):
    id: str = Field(pattern=r"^[A-Za-z0-9_-]{1,36}$")
    project_id: str = Field(pattern=r"^[A-Za-z0-9_-]{1,36}$")
    name: str = Field(min_length=1, max_length=120, repr=False)
    environment: str = Field(pattern=r"^[a-z][a-z0-9_-]{0,63}$")
    revision: int = Field(ge=1)
    entries: list[SecretReference] = Field(min_length=1, max_length=32, repr=False)
    permissions: list[Literal["read", "edit", "share"]] = Field(max_length=3)
    created_at: str
    updated_at: str

    @field_validator("created_at", "updated_at")
    @classmethod
    def timestamp(cls, value: str) -> str:
        if len(value) > 40 or datetime.fromisoformat(value.replace("Z", "+00:00")).tzinfo is None:
            raise ValueError("invalid timestamp")
        return value

    @field_validator("name")
    @classmethod
    def safe_name(cls, value: str) -> str:
        if any(ord(char) < 32 or ord(char) == 127 for char in value):
            raise ValueError("invalid profile name")
        return value

    @model_validator(mode="after")
    def unique_entries(self) -> "ResolvedProfile":
        if (
            len({item.alias for item in self.entries}) != len(self.entries)
            or len({item.secret_id for item in self.entries}) != len(self.entries)
            or len(set(self.permissions)) != len(self.permissions)
            or "read" not in self.permissions
        ):
            raise ValueError("invalid metadata references")
        return self

    def reference(self, alias: str) -> SecretReference:
        for entry in self.entries:
            if entry.alias == alias:
                return entry
        raise AdapterError("profile_alias_unavailable")


class ResolveRequest(StrictMetadata):
    project_id: str = Field(pattern=r"^[A-Za-z0-9_-]{1,36}$")
    profile_id: str = Field(pattern=r"^[A-Za-z0-9_-]{1,36}$")
    revision: int = Field(ge=1)
    purpose: Purpose
    provider: Provider | None

    @model_validator(mode="after")
    def provider_scope(self) -> "ResolveRequest":
        if (self.purpose in {"use_tool", "use_model"}) != (self.provider is not None):
            raise ValueError("invalid provider scope")
        return self


def resolve_profile(
    authenticated_post: AuthenticatedPost,
    *,
    project_id: str,
    profile_id: str,
    revision: int,
    purpose: Purpose,
    provider: Provider | None = None,
) -> ResolvedProfile:
    """Perform exactly one current metadata resolve, without retries or value operations.

    The callback must enforce its own finite HTTP deadline and same trusted
    origin, and return a decoded JSON object. It receives only a fixed API path
    and non-secret body; credentials are not arguments to this helper.
    """
    try:
        request = ResolveRequest(
            project_id=project_id,
            profile_id=profile_id,
            revision=revision,
            purpose=purpose,
            provider=provider,
        )
    except Exception:
        raise AdapterError("invalid_profile_request") from None
    path = f"/api/v1/projects/{request.project_id}/secret-profiles/{request.profile_id}/resolve"
    try:
        value = authenticated_post(
            path,
            {
                "revision": request.revision,
                "purpose": request.purpose,
                "provider": request.provider,
            },
        )
    except Exception:
        # Callback errors may carry HTTP bodies or credentials. Never reflect them.
        raise AdapterError("profile_resolution_unavailable") from None
    try:
        result = ResolvedProfile.model_validate(value)
        if (result.id, result.project_id, result.revision) != (
            request.profile_id,
            request.project_id,
            request.revision,
        ):
            raise ValueError("profile binding mismatch")
        return result
    except Exception:
        raise AdapterError("invalid_profile_response") from None
