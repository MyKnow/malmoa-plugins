"""Browser-approved scope, local preflight, then a one-use native project claim."""

import re
import time
import webbrowser
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Literal

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, SecretStr, model_validator

from durumari_mcp.browser_login import browser_origin
from durumari_mcp.credentials import AdapterError
from durumari_mcp.project_gateway import ProjectConnection, ProjectTransport


class PreparedScope(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    project_id: str = Field(pattern=r"^[A-Za-z0-9-]{1,36}$")
    source_id: str = Field(pattern=r"^[A-Za-z0-9-]{1,36}$")
    actor_id: str = Field(pattern=r"^[A-Za-z0-9-]{1,36}$")
    host: Literal["codex", "claude"]
    actions: list[Literal["read", "capture"]]

    @model_validator(mode="after")
    def valid_actions(self) -> "PreparedScope":
        if "read" not in self.actions or len(set(self.actions)) != len(self.actions):
            raise ValueError("invalid actions")
        return self


class ClaimedTokens(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    connection: ProjectConnection
    access_token: SecretStr = Field(repr=False)
    refresh_token: SecretStr = Field(repr=False)
    access_expires_at: AwareDatetime

    @model_validator(mode="after")
    def valid_tokens(self) -> "ClaimedTokens":
        if not re.fullmatch(r"mpa_[A-Za-z0-9_-]{43}", self.access_token.get_secret_value()):
            raise ValueError("invalid access token")
        if not re.fullmatch(r"mpr_[A-Za-z0-9_-]{43}", self.refresh_token.get_secret_value()):
            raise ValueError("invalid refresh token")
        return self


@dataclass
class ProjectHandoff:
    transport: ProjectTransport = field(repr=False)
    scope: PreparedScope
    environment_name: str
    device_token: str = field(repr=False)
    accepted: bool = False
    claimed: bool = False

    def exchange(self) -> dict[str, Any]:
        if self.claimed:
            raise AdapterError("project_request_already_claimed")
        # Never retry a consumed claim. Private cancellation can revoke it even
        # if its response is lost, before any credential was available locally.
        self.claimed = True
        value = self.transport.request(
            "/api/v1/auth/plugin/exchange", body={"device_token": self.device_token}
        )
        try:
            if set(value) != {"status", "tokens"} or value["status"] != "approved":
                raise ValueError
            tokens = ClaimedTokens.model_validate(value["tokens"])
        except (KeyError, TypeError, ValueError):
            raise AdapterError("invalid_project_connection") from None
        row = tokens.connection
        if (
            row.project_id,
            row.source_id,
            row.actor_id,
            row.host,
            sorted(row.actions),
            row.provider,
            row.environment_name,
            row.state,
        ) != (
            self.scope.project_id,
            self.scope.source_id,
            self.scope.actor_id,
            self.scope.host,
            sorted(self.scope.actions),
            {"codex": "openai", "claude": "anthropic"}[self.scope.host],
            self.environment_name,
            "active",
        ):
            raise AdapterError("project_connection_scope_changed")
        return {
            "connection": row.model_dump(mode="json"),
            "access_token": tokens.access_token.get_secret_value(),
            "refresh_token": tokens.refresh_token.get_secret_value(),
            "access_expires_at": tokens.access_expires_at.isoformat(),
        }

    def accept(self) -> None:
        if not self.claimed:
            raise AdapterError("project_request_not_claimed")
        self.accepted = True


@contextmanager
def browser_project_connect(
    transport: ProjectTransport,
    client: Literal["codex", "claude"],
    *,
    browser_address: str,
    environment_name: str,
    project_id: str | None = None,
    source_id: str | None = None,
) -> Iterator[ProjectHandoff]:
    origin = browser_origin(browser_address, transport.origin)
    value = transport.request(
        "/api/v1/auth/plugin/requests",
        body={
            "client": client,
            "mode": "project",
            "environment_name": environment_name,
            "project_id": project_id,
            "source_id": source_id,
        },
    )
    device = value.get("device_token")
    if not isinstance(device, str) or not re.fullmatch(r"[A-Za-z0-9_-]{43}", device):
        raise AdapterError("invalid_browser_login_request")
    handoff = None
    try:
        request_id, path, code = (
            value.get("request_id"),
            value.get("verification_path"),
            value.get("confirmation_code"),
        )
        if (
            not isinstance(request_id, str)
            or not re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", request_id)
            or path != f"/connect?client={client}&request={request_id}"
            or not isinstance(code, str)
            or not re.fullmatch(r"[0-9A-F]{8}", code)
        ):
            raise AdapterError("invalid_browser_login_request")
        print("브라우저에서 로그인하고 연결할 공간을 승인해 주세요.")
        print("연결 확인 코드: " + code)
        print("연결 주소: " + origin + path, flush=True)
        webbrowser.open(origin + path)
        deadline = time.monotonic() + 600
        while time.monotonic() < deadline:
            response = transport.request(
                "/api/v1/auth/plugin/exchange", body={"device_token": device, "prepare": True}
            )
            if response.get("status") == "ready":
                try:
                    if set(response) != {"status", "scope"}:
                        raise ValueError
                    scope = PreparedScope.model_validate(response["scope"])
                except (KeyError, TypeError, ValueError):
                    raise AdapterError("invalid_browser_login_response") from None
                if (
                    scope.host != client
                    or (project_id and scope.project_id != project_id)
                    or (source_id and scope.source_id != source_id)
                ):
                    raise AdapterError("project_connection_scope_changed")
                handoff = ProjectHandoff(transport, scope, environment_name, device)
                yield handoff
                return
            if response != {"status": "pending"}:
                raise AdapterError("invalid_browser_login_response")
            time.sleep(5)
        raise AdapterError("browser_login_expired")
    except KeyboardInterrupt:
        raise AdapterError("project_connection_cancelled") from None
    finally:
        if handoff is None or not handoff.accepted:
            try:
                transport.request("/api/v1/auth/plugin/cancel", body={"device_token": device})
            except AdapterError:
                raise AdapterError("project_bootstrap_cleanup_not_confirmed") from None
