"""Human-operated local onboarding; never carries account sessions into MCP."""

import base64
import getpass
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from urllib.parse import urlencode

from pydantic import SecretStr

from durumari_mcp.credentials import AdapterError
from durumari_mcp.legacy import manifest_path as existing_manifest_path
from durumari_mcp.onboarding import (
    configured_profile,
    contains_sensitive_migration,
    digest,
    host_checks,
    init_project,
    load_manifest,
    migration_state,
    profile_for,
    record_migration,
    repository_diagnostics,
    scan_project,
)
from durumari_mcp.project_gateway import ProjectGateway, ProjectTransport


def review_bundle(bundle: Any) -> dict[str, Any]:
    """Validate every portable payload before the first remote mutation."""
    from pathlib import PurePosixPath

    from durumari_mcp.capture import contains_sensitive
    from durumari_mcp.context_tools import ContextPayload

    try:
        json.dumps(bundle, allow_nan=False)
        if (
            not isinstance(bundle, dict)
            or type(bundle.get("schema_version")) is not int
            or bundle["schema_version"] != 1
            or type(bundle.get("complete")) is not bool
            or not isinstance(bundle.get("omissions"), list)
            or not isinstance(bundle.get("documents"), list)
        ):
            raise ValueError
        documents = []
        for row in bundle["documents"]:
            value = ContextPayload.model_validate(
                {k: v for k, v in row.items() if k in {"kind", "title", "body", "document"}}
            ).model_dump(mode="json", exclude_none=True)

            def has_nul(item: Any) -> bool:
                if isinstance(item, str):
                    return "\x00" in item
                if isinstance(item, dict):
                    return any(has_nul(k) or has_nul(v) for k, v in item.items())
                if isinstance(item, list):
                    return any(has_nul(v) for v in item)
                return False

            visible = {k: v for k, v in value.items() if k != "document"}
            if value.get("document"):
                visible["document"] = {k: v for k, v in value["document"].items() if k != "assets"}
            if contains_sensitive_migration(visible) or has_nul(value):
                raise ValueError
            source = value.get("document")
            if source:
                if (
                    set(source) - {"raw", "path", "sha256", "metadata", "links", "assets"}
                    or not isinstance(source.get("metadata", {}), dict)
                    or len(source.get("links", [])) > 200
                    or len(source.get("assets", [])) > 32
                ):
                    raise ValueError

                def path_safe(path: str) -> bool:
                    return (
                        isinstance(path, str)
                        and 0 < len(path) <= 1000
                        and not PurePosixPath(path).is_absolute()
                        and ".." not in PurePosixPath(path).parts
                        and not any(c in path for c in ("\\", ":", "\x00"))
                    )

                if not path_safe(source["path"]) or source["sha256"] != digest(
                    (source.get("raw") if source.get("raw") is not None else value["body"]).encode()
                ):
                    raise ValueError
                if source.get("raw") is not None and len(source["raw"]) > 40_000:
                    raise ValueError
                seen = set()
                for asset in source.get("assets", []):
                    if (
                        set(asset) != {"path", "media_type", "sha256", "data"}
                        or not path_safe(asset["path"])
                        or asset["path"] in seen
                        or not isinstance(asset["media_type"], str)
                        or not 1 <= len(asset["media_type"]) <= 100
                    ):
                        raise ValueError
                    data = base64.b64decode(asset["data"], validate=True)
                    if (
                        len(data) > 524_288
                        or digest(data) != asset["sha256"]
                        or contains_sensitive({k: v for k, v in asset.items() if k != "data"})
                        or contains_sensitive(data.decode("utf-8", errors="ignore"))
                    ):
                        raise ValueError
                    seen.add(asset["path"])
                if len(json.dumps(source, allow_nan=False).encode()) > 2_097_152:
                    raise ValueError
            documents.append(value)
        return {**bundle, "documents": documents}
    except (ValueError, TypeError, KeyError, AttributeError):
        raise AdapterError("invalid_or_sensitive_migration_bundle") from None


def add_commands(commands: Any) -> None:
    init = commands.add_parser(
        "project-init", help="Preview or apply repository binding and host settings"
    )
    init.add_argument("--workspace", required=True)
    init.add_argument("--gateway-origin")
    init.add_argument("--project-id")
    init.add_argument("--source-id")
    init.add_argument(
        "--hosts", nargs="+", choices=["codex", "claude"], default=["codex", "claude"]
    )
    init.add_argument("--apply", action="store_true")
    init.add_argument("--for-migration", action="store_true")
    init.add_argument("--login", action="store_true")
    init.add_argument("--allow-external-context", action="store_true")
    init.add_argument("--create-project")
    init.add_argument("--workspace-id")
    for name in ("project-import", "project-export", "project-doctor", "project-preflight"):
        command = commands.add_parser(
            name, help="Reviewed project migration or connection diagnosis"
        )
        command.add_argument("--workspace", required=True)
        command.add_argument("--profile")
        command.add_argument("--client", choices=["codex", "claude"], default="codex")
        if name == "project-preflight":
            command.add_argument("--change", choices=["git-init", "move", "detach"], required=True)
            command.add_argument("--target-workspace")
        if name == "project-import":
            command.add_argument("--paths", nargs="+", default=["docs"])
            command.add_argument("--include-resources", action="store_true")
            command.add_argument("--reference-source-code", action="store_true")
            command.add_argument("--apply", action="store_true")
            command.add_argument("--allow-incomplete", action="store_true")
            command.add_argument("--bundle")
            command.add_argument("--output")
        if name == "project-export":
            command.add_argument("--output", required=True)
            command.add_argument("--local", action="store_true")
            command.add_argument("--paths", nargs="+", default=["docs"])
            command.add_argument("--include-resources", action="store_true")


def write_private(path: Path, value: dict[str, Any]) -> None:
    if path.exists() or path.is_symlink():
        raise AdapterError("output_exists_choose_new_path")
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())


def gateway_for(args: Any, root: Path) -> ProjectGateway:
    manifest = load_manifest(root)
    gateway = ProjectGateway(
        args.profile
        or configured_profile(root, args.client)
        or profile_for(manifest["project_id"], args.client, root),
        args.client,
    )
    gateway.profile.check_workspace(str(root))
    if (gateway.profile.gateway_origin, gateway.profile.project_id, gateway.profile.source_id) != (
        manifest["server"],
        manifest["project_id"],
        manifest["source_id"],
    ):
        raise AdapterError("project_manifest_profile_mismatch")
    return gateway


def export_server(gateway: ProjectGateway) -> dict[str, Any]:
    after = ""
    items = []
    cursor = None
    server_time = None
    seen = set()
    for _ in range(200):
        page = gateway.request("/api/v1/project-agent/contexts?" + urlencode({"after": after}))
        if page.get("project_id") != gateway.profile.project_id:
            raise AdapterError("document_scope_mismatch")
        if cursor is None:
            cursor = page["cursor"]
        if cursor != page["cursor"]:
            raise AdapterError("project_changed_repeat_export")
        items.extend(page["items"])
        server_time = page["server_time"]
        next_after = page["next_after"]
        if next_after is None:
            return {
                "schema_version": 1,
                "project_id": page["project_id"],
                "server_time": server_time,
                "cursor": cursor,
                "documents": items,
                "complete": True,
                "omissions": page["omissions"],
            }
        if next_after in seen:
            raise AdapterError("repeated_document_cursor")
        seen.add(next_after)
        after = next_after
    raise AdapterError("document_export_page_limit")


def initialize(args: Any, root: Path) -> dict[str, Any]:
    from durumari_mcp.project_cli import project_login

    if args.create_project:
        if (
            not args.apply
            or not args.gateway_origin
            or not args.workspace_id
            or not args.allow_external_context
            or not sys.stdin.isatty()
        ):
            raise AdapterError("project_creation_requires_apply_workspace_and_consent")
        transport = ProjectTransport(args.gateway_origin)
        native = transport.request(
            "/api/v1/auth/native/login",
            body={
                "email": getpass.getpass("Durumari email (hidden): "),
                "password": getpass.getpass("Durumari password: "),
                "device_name": "Durumari project initialization",
            },
        )
        token = SecretStr(native["access_token"])
        try:
            projects = transport.request(
                "/api/v1/workspaces/" + args.workspace_id + "/projects",
                token=token,
                scheme="Bearer",
            )["items"]
            matching = [p for p in projects if p["name"] == args.create_project]
            if len(matching) > 1:
                raise AdapterError("ambiguous_existing_project")
            project = (
                matching[0]
                if matching
                else transport.request(
                    "/api/v1/workspaces/" + args.workspace_id + "/projects",
                    token=token,
                    scheme="Bearer",
                    body={"name": args.create_project},
                )
            )
            args.project_id = project["id"]
            sources = transport.request(
                "/api/v1/projects/" + args.project_id + "/sources", token=token, scheme="Bearer"
            )["items"]
            matching = [
                s
                for s in sources
                if s["external_id"] == "durumari-project-documents" and s["provider"] == "direct"
            ]
            if len(matching) > 1:
                raise AdapterError("ambiguous_existing_source")
            source = (
                matching[0]
                if matching
                else transport.request(
                    "/api/v1/projects/" + args.project_id + "/sources",
                    token=token,
                    scheme="Bearer",
                    body={
                        "provider": "direct",
                        "external_id": "durumari-project-documents",
                        "visibility": "project",
                    },
                )
            )
            args.source_id = source["id"]
            providers = sorted({"openai" if c == "codex" else "anthropic" for c in args.hosts})
            # Only configure a newly created source. An existing source policy
            # requires its owner's explicit management, never silent expansion.
            if not matching:
                transport.request(
                    "/api/v1/projects/"
                    + args.project_id
                    + "/sources/"
                    + args.source_id
                    + "/policy",
                    token=token,
                    scheme="Bearer",
                    method="PUT",
                    body={
                        "revision": source["policy_revision"],
                        "active": True,
                        "visibility": "project",
                        "routing_mode": "cloud_preferred",
                        "allowed_plugin_providers": providers,
                    },
                )
        finally:
            transport.request(
                "/api/v1/auth/sessions/" + native["session_id"],
                token=token,
                scheme="Bearer",
                method="DELETE",
            )
    if existing_manifest_path(root).exists():
        existing = load_manifest(root)
        args.gateway_origin = args.gateway_origin or existing["server"]
        args.project_id = args.project_id or existing["project_id"]
        args.source_id = args.source_id or existing["source_id"]
    if not all((args.gateway_origin, args.project_id, args.source_id)):
        raise AdapterError("project_binding_arguments_required")
    if args.login and not args.apply:
        raise AdapterError("login_requires_apply")
    result = init_project(
        root,
        args.gateway_origin,
        args.project_id,
        args.source_id,
        args.hosts,
        apply=args.apply,
        for_migration=args.for_migration,
    )
    if args.login:
        for client in args.hosts:
            project_login(
                SimpleNamespace(
                    profile=result["profiles"][client],
                    client=client,
                    gateway_origin=args.gateway_origin,
                    workspace=str(root),
                    project_id=args.project_id,
                    source_id=args.source_id,
                    environment_name=client + "-" + root.name,
                    allow_external_context=args.allow_external_context,
                )
            )
    return result


def execute_onboarding(args: Any) -> None:
    root = Path(args.workspace).resolve(strict=True)
    if args.command == "project-preflight":
        result = repository_diagnostics(root)
        if args.change == "git-init":
            predicted = (
                result["current_repository_id"]
                if (root / ".git").exists()
                else digest(("local:" + str(root / ".git")).encode())
            )
            reconnect = predicted != result["bound_repository_id"]
        else:
            predicted = None
            reconnect = True  # Workspace scope changes even if a remote stays the same.
        result.update(
            change=args.change,
            predicted_repository_id=predicted,
            reconnect_required=reconnect or not result["repository_matches"],
            recovery_plan=[
                "preserve_connection_files_and_pending_records",
                "prepare_final_folder_and_git_structure",
                "browser_approve_existing_project_connection",
                "verify_status_reload_host_then_resume",
            ],
        )
        print(json.dumps(result, ensure_ascii=False))
        return
    if args.command == "project-doctor":
        result = repository_diagnostics(root)
        if not result["repository_matches"]:
            print(json.dumps(result, ensure_ascii=False))
            return
    if args.command == "project-init":
        print(json.dumps(initialize(args, root), ensure_ascii=False))
        return
    if args.command == "project-import":
        if args.bundle:
            path = Path(args.bundle)
            if path.stat().st_size > 50_000_000:
                raise AdapterError("bundle_size_limit")
            bundle = json.loads(path.read_text())
        else:
            bundle = scan_project(
                root,
                args.paths,
                include_resources=args.include_resources,
                reference_source_code=args.reference_source_code,
            )
        bundle = review_bundle(bundle)
        if args.output and (Path(args.output).exists() or Path(args.output).is_symlink()):
            raise AdapterError("output_exists_choose_new_path")
        preview = {
            "documents": len(bundle["documents"]),
            "complete": bundle["complete"],
            "omissions": bundle["omissions"],
            "applied": False,
        }
        if not args.apply:
            if args.output:
                write_private(Path(args.output), bundle)
            print(json.dumps(preview, ensure_ascii=False))
            return
        if not bundle["complete"] and not args.allow_incomplete:
            raise AdapterError("incomplete_migration_review_required")
        gateway = gateway_for(args, root)
        receipts = []
        # Fresh scan immediately before mutation; originals remain unchanged.
        if (
            not args.bundle
            and scan_project(
                root,
                args.paths,
                include_resources=args.include_resources,
                reference_source_code=args.reference_source_code,
            )
            != bundle
        ):
            raise AdapterError("source_changed_repeat_preview")
        record_migration(root, gateway.profile.project_id, "pending")
        for row in bundle["documents"]:
            key = "import-" + digest(
                json.dumps(
                    [gateway.profile.project_id, row], sort_keys=True, ensure_ascii=False
                ).encode()
            )
            value = gateway.request(
                "/api/v1/project-agent/contexts", row, action="capture", idempotency_key=key
            )
            if value.get("project_id") != gateway.profile.project_id or any(
                value.get(k) != row[k] for k in ("kind", "body", "document")
            ):
                raise AdapterError("migration_receipt_mismatch")
            receipts.append(
                {
                    "path": row["document"]["path"] if row.get("document") else None,
                    "context_id": value["id"],
                    "revision": value["revision"],
                    "policy_revision": value["policy_revision"],
                }
            )
        record_migration(
            root,
            gateway.profile.project_id,
            "verified" if bundle["complete"] else "partial_reviewed",
        )
        result = {
            **preview,
            "applied": True,
            "project_id": gateway.profile.project_id,
            "receipts": receipts,
            "verification": "server_committed_receipts_match",
            "originals": "preserved",
        }
        if args.output:
            write_private(Path(args.output), result)
        print(json.dumps(result, ensure_ascii=False))
        return
    if args.command == "project-export":
        result = (
            scan_project(root, args.paths, include_resources=args.include_resources)
            if args.local
            else export_server(gateway_for(args, root))
        )
        write_private(Path(args.output), result)
        print(
            json.dumps(
                {
                    "output": args.output,
                    "documents": len(result["documents"]),
                    "complete": result["complete"],
                },
                ensure_ascii=False,
            )
        )
        return
    try:
        gateway = gateway_for(args, root)
    except AdapterError as error:
        from durumari_mcp.hook_recovery import HUMAN_ACTION_ERRORS

        if args.command != "project-doctor" or str(error) not in HUMAN_ACTION_ERRORS:
            raise
        result = repository_diagnostics(root)
        result.update(reason=str(error), capture_paused=True, next_action="browser_reconnect")
        print(json.dumps(result, ensure_ascii=False))
        return
    connection = gateway.request("/api/v1/project-agent/connection", action=None)
    first = gateway.request("/api/v1/project-agent/contexts")
    checks = host_checks(root, gateway.profile.project_id, args.client, gateway.name)
    from durumari_mcp.codex_host import inspect_host

    host = (
        inspect_host(root)
        if args.client == "codex"
        else {"state": "unverified", "reason": "host_approval_required"}
    )
    if args.client == "codex":
        checks["effective_codex_config"] = host["state"] == "configured"
    print(
        json.dumps(
            {
                "project_id": first["project_id"],
                "server_time": first["server_time"],
                "cursor": first["cursor"],
                "connection_state": connection["state"],
                "migration_state": migration_state(root, gateway.profile.project_id),
                "checks": checks,
                "host_setup": host,
                "ready": all(checks.values()),
                "host_capture_status": connection["capture_status"],
                "scope": "current_authorized_server_page",
            },
            ensure_ascii=False,
        )
    )
    if not all(checks.values()):
        raise AdapterError("host_setup_incomplete")
