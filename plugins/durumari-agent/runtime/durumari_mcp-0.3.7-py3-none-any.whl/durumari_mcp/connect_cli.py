"""Human-guided onboarding: select names instead of assembling credential arguments."""

import getpass
import re
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from uuid import uuid4

from pydantic import SecretStr

from durumari_mcp import project_credentials
from durumari_mcp.browser_login import browser_login, browser_origin
from durumari_mcp.browser_project_connect import browser_project_connect
from durumari_mcp.credentials import AdapterError
from durumari_mcp.legacy import manifest_path as existing_manifest_path
from durumari_mcp.onboarding import (
    configured_profile,
    init_project,
    profile_for,
    read_manifest,
    repository_identity,
)
from durumari_mcp.project_cli import configure_project, replace_project_credentials
from durumari_mcp.project_credentials import ProjectProfile, load_project_profile
from durumari_mcp.project_gateway import (
    ProjectConnection,
    ProjectGateway,
    ProjectTransport,
    validate_connection,
)

visible_input = input
hidden_input = getpass.getpass


def _input(prompt: str, *, hidden: bool = False) -> str:
    try:
        return hidden_input(prompt) if hidden else visible_input(prompt)
    except (EOFError, KeyboardInterrupt):
        raise AdapterError("project_connection_cancelled") from None


def _label(value: Any) -> str:
    return re.sub(r"[\x00-\x1f\x7f-\x9f]", " ", str(value))[:200]


def _items(value: dict[str, Any]) -> list[dict[str, Any]]:
    rows = value.get("items")
    if not isinstance(rows, list) or len(rows) > 1000:
        raise AdapterError("invalid_project_selection")
    if any(
        not isinstance(row, dict)
        or not isinstance(row.get("id"), str)
        or not re.fullmatch(r"[A-Za-z0-9-]{1,128}", row["id"])
        for row in rows
    ):
        raise AdapterError("invalid_project_selection")
    return rows


def _choose(title: str, rows: list[dict[str, Any]], label: str = "name") -> dict[str, Any]:
    if not rows:
        raise AdapterError("project_selection_unavailable")
    print(title)
    for index, row in enumerate(rows, 1):
        print(f"  {index}. {_label(row.get(label, ''))}")
    for _ in range(3):
        selection = _input("번호 선택 (취소: Enter): ").strip()
        if not selection:
            raise AdapterError("project_connection_cancelled")
        if selection.isascii() and selection.isdigit() and 1 <= int(selection) <= len(rows):
            return rows[int(selection) - 1]
        print("목록에 있는 번호를 입력해 주세요.")
    raise AdapterError("project_selection_invalid")


def _yes(prompt: str) -> bool:
    return _input(prompt + " [y/N]: ").strip().lower() in {"y", "yes", "예"}


@contextmanager
def _native_login(transport: ProjectTransport, client: str | None = None) -> Iterator[SecretStr]:
    if client is not None:
        with browser_login(transport, client) as token:
            yield token
        return
    print("로그인 서버: " + transport.origin)
    email = _input("이메일 (숨김 입력): ", hidden=True)
    password = _input("비밀번호 (숨김 입력): ", hidden=True)
    native = transport.request(
        "/api/v1/auth/native/login",
        body={"email": email, "password": password, "device_name": "Project connection setup"},
    )
    del email, password
    try:
        session = native["session_id"]
        token = SecretStr(native["access_token"])
        if not isinstance(session, str) or not re.fullmatch(r"[A-Za-z0-9-]{1,64}", session):
            raise ValueError
        if not token.get_secret_value():
            raise ValueError
    except Exception:
        raise AdapterError("invalid_native_session") from None
    try:
        yield token
    finally:
        try:
            transport.request(
                "/api/v1/auth/sessions/" + session, token=token, scheme="Bearer", method="DELETE"
            )
        except AdapterError:
            raise AdapterError("native_bootstrap_logout_not_confirmed") from None
        finally:
            del native, token


def _existing(name: str) -> ProjectProfile | None:
    try:
        return load_project_profile(name)
    except AdapterError as error:
        if str(error) != "project_credential_missing":
            raise
        return None


def _recover(
    name: str,
    previous: ProjectProfile,
    transport: ProjectTransport,
    browser_client: str | None = None,
    *, repository_id: str | None = None,
) -> None:
    print("다시 로그인합니다. 기존 작업 기록은 보존합니다.")
    # Hold the same lock used by hooks throughout token issuance and persistence.
    # No hook can replay an old refresh token after successful human recovery.
    from durumari_mcp.project_outbox import process_lock, state_root

    with _native_login(transport, browser_client) as token:
        with process_lock(state_root() / (name + ".credentials")):
            current = load_project_profile(name)
            if current.protected_json() != previous.protected_json():
                raise AdapterError("project_profile_changed")
            rows = _items(
                transport.request(
                    "/api/v1/projects/" + previous.project_id + "/project-connections",
                    token=token,
                    scheme="Bearer",
                )
            )
            row = next((item for item in rows if item["id"] == previous.connection_id), None)
            if row is None:
                raise AdapterError("project_connection_unavailable")
            connection = validate_connection(row, previous)
            result = transport.request(
                "/api/v1/project-connections/" + connection.id + "/reauthenticate",
                token=token,
                scheme="Bearer",
                body={"revision": connection.revision},
            )
            replace_project_credentials(
                name, previous, result, locked=True, repository_id=repository_id
            )


def refresh_server_setup(
    root: Path, origin: str, project: str, source: str, name: str, client: str,
    *, approved_rebind: dict[str, Any] | None = None,
) -> None:
    from durumari_mcp.setup_files import server_instructions

    if approved_rebind is not None:
        # A deliberately narrow recovery transport. Context/capture Gateway
        # remains closed until server scope and local files have been verified.
        profile = load_project_profile(name)
        profile.check_client(client)
        if (profile.gateway_origin, profile.project_id, profile.source_id, profile.workspace) != (
            origin, project, source, str(root)
        ):
            raise AdapterError("project_connection_scope_changed")
        transport = ProjectTransport(origin)
        validate_connection(
            transport.request("/api/v1/project-agent/connection", token=profile.access_token),
            profile,
        )
        bundle = transport.request(
            "/api/v1/project-agent/connection-files", token=profile.access_token
        )
    else:
        gateway = ProjectGateway(name, client)
        bundle = gateway.request("/api/v1/project-agent/connection-files")
    block = server_instructions(bundle, origin, project, source)
    init_project(
        root,
        origin,
        project,
        source,
        [client],
        apply=True,
        preserve_disabled_hooks=True,
        profile_names={client: name},
        instruction_block=block,
        approved_rebind=approved_rebind,
    )


def connect_project(args: Any) -> dict[str, Any]:
    interactive = sys.stdin.isatty()
    if not interactive and not getattr(args, "browser_login", False):
        raise AdapterError("interactive_project_login_required")
    root = Path(args.workspace).resolve()
    if not root.exists() and getattr(args, "create_workspace", False):
        try:
            root.mkdir(parents=True, exist_ok=True)
        except OSError:
            raise AdapterError("workspace_create_failed") from None
    if not root.is_dir():
        raise AdapterError("workspace_directory_required")
    if getattr(args, "trust_workspace", False):
        if args.client != "codex":
            raise AdapterError("codex_trust_option_requires_codex")
        from durumari_mcp.codex_host import trust_workspace

        trust_workspace(root)
    manifest = read_manifest(root) if existing_manifest_path(root).exists() else None
    identity = repository_identity(root)
    rebind: dict[str, Any] | None = (
        {"manifest": manifest, "repository_id": identity}
        if manifest and manifest.get("repository_id", identity) != identity else None
    )
    if rebind is not None and not getattr(args, "browser_login", False):
        raise AdapterError("repository_reconnect_requires_browser_approval")
    requested = getattr(args, "requested_project", None)
    if requested and not re.fullmatch(r"[A-Za-z0-9-]{1,36}", requested):
        raise AdapterError("invalid_project_binding")
    if requested and manifest and requested != manifest["project_id"]:
        raise AdapterError("project_manifest_conflict")
    supplied = getattr(args, "gateway_origin", None)
    if manifest and supplied and supplied != manifest["server"]:
        raise AdapterError("project_manifest_conflict")
    if not supplied and not manifest and not interactive:
        raise AdapterError("project_service_origin_required")
    origin = supplied or (manifest["server"] if manifest else _input("서버 주소: ").strip())
    transport = ProjectTransport(origin)
    # Establish that the approved secure store exists before asking for account secrets.
    project_credentials.require_project_store()
    name = configured_profile(root, args.client)
    if not name and manifest:
        name = profile_for(manifest["project_id"], args.client, root)
    previous = _existing(name) if name else None
    if (
        previous and previous.workspace == str(root)
        and previous.repository_id not in {None, identity}
    ):
        rebind = {"manifest": manifest, "repository_id": identity}
        if not getattr(args, "browser_login", False):
            raise AdapterError("repository_reconnect_requires_browser_approval")
    retained_profile = None
    if previous:
        assert name is not None
        if not manifest or (
            previous.gateway_origin,
            previous.project_id,
            previous.source_id,
            previous.client,
        ) != (
            manifest["server"],
            manifest["project_id"],
            manifest["source_id"],
            args.client,
        ):
            raise AdapterError("project_connection_scope_changed")
        if previous.workspace != str(root):
            if not getattr(args, "browser_login", False):
                raise AdapterError("repository_reconnect_requires_browser_approval")
            # A copied/moved workspace enrolls separately. Never move or replay
            # another workspace's encrypted pending records into this connection.
            retained_profile = name
            name = profile_for(manifest["project_id"], args.client, root) + "-" + uuid4().hex[:8]
            previous = None
    if previous:
        assert name is not None
        if rebind is not None:
            init_project(
                root, origin, previous.project_id, previous.source_id, [args.client],
                apply=False, preserve_disabled_hooks=True, profile_names={args.client: name},
                approved_rebind=rebind,
            )
            print("저장소 연결을 다시 승인합니다. 기존 프로젝트와 대기 기록은 유지합니다.")
            print("프로젝트: " + previous.project_id + " / 작업 폴더: " + _label(root))
        if rebind is None and not getattr(args, "reauth", False):
            try:
                ProjectGateway(name, args.client).request("/api/v1/project-agent/connection")
            except AdapterError as error:
                if str(error) not in {"project_login_required", "project_access_denied"}:
                    raise
                # A failed rotation may have durably changed the uncertainty flag.
                previous = load_project_profile(name)
            else:
                if getattr(args, "browser_login", False):
                    config = transport.request("/api/v1/auth/plugin/config")
                    if config.get("project_setup_files") is True:
                        refresh_server_setup(
                            root, origin, previous.project_id, previous.source_id, name, args.client
                        )
                from durumari_mcp.codex_host import connection_notice

                connection_notice(root, args.client)
                return {"profile": name, "status": "connected"}
        _recover(
            name,
            previous,
            transport,
            args.client if getattr(args, "browser_login", False) else None,
            repository_id=identity if rebind is not None else None,
        )
        if getattr(args, "browser_login", False):
            config = transport.request("/api/v1/auth/plugin/config")
            if config.get("project_setup_files") is True:
                refresh_server_setup(
                    root, origin, previous.project_id, previous.source_id, name, args.client,
                    approved_rebind=rebind,
                )
            elif rebind is not None:
                raise AdapterError("repository_reconnect_requires_server_setup_files")
        if rebind is not None:
            ProjectGateway(name, args.client).request("/api/v1/project-agent/connection")
            from durumari_mcp.codex_host import connection_notice

            connection_notice(root, args.client)
            return {
                "profile": name, "status": "repository_reconnected", "pending_records": "preserved"
            }
        print("로그인을 갱신했습니다. 기존 작업 기록과 설정은 유지됩니다.")
        return {"profile": name, "status": "reauthenticated"}

    if getattr(args, "browser_login", False):
        config = transport.request("/api/v1/auth/plugin/config")
        if config.get("project_connect") is True:
            with browser_project_connect(
                transport,
                args.client,
                browser_address=browser_origin(config.get("browser_origin"), transport.origin),
                environment_name=(_label(args.client + "-" + root.name))[:100],
                project_id=manifest["project_id"] if manifest else requested,
                source_id=manifest["source_id"] if manifest else None,
            ) as handoff:
                project, source = handoff.scope.project_id, handoff.scope.source_id
                if requested and project != requested:
                    raise AdapterError("project_connection_scope_changed")
                name = name or profile_for(project, args.client, root)
                if _existing(name):
                    raise AdapterError("project_profile_exists_use_existing_binding")
                from durumari_mcp.project_outbox import state_root

                if (state_root() / name / "queue.enc").exists():
                    raise AdapterError("profile_has_existing_outbox_use_new_name")
                setup: dict[str, Any] = dict(
                    for_migration=getattr(args, "for_migration", False),
                    preserve_disabled_hooks=True,
                    profile_names={args.client: name},
                    approved_rebind=rebind,
                    previous_profile_names=(
                        {args.client: retained_profile} if retained_profile else None
                    ),
                )
                init_project(root, origin, project, source, [args.client], apply=False, **setup)
                claimed = handoff.exchange()
                if (project, source) != (
                    claimed["connection"]["project_id"], claimed["connection"]["source_id"]
                ):
                    raise AdapterError("project_connection_scope_changed")
                if config.get("project_setup_files") is True:
                    from durumari_mcp.setup_files import server_instructions

                    bundle = transport.request(
                        "/api/v1/project-agent/connection-files",
                        token=SecretStr(claimed["access_token"]),
                        scheme="ProjectPlugin",
                    )
                    setup["instruction_block"] = server_instructions(
                        bundle, origin, project, source
                    )
                init_project(root, origin, project, source, [args.client], apply=True, **setup)
                configure_project(
                    SimpleNamespace(
                        profile=name,
                        client=args.client,
                        workspace=str(root),
                        gateway_origin=origin,
                        quiet=True,
                    ),
                    claimed,
                )
                handoff.accept()
            from durumari_mcp.codex_host import connection_notice

            connection_notice(root, args.client)
            connection_result = {"profile": name, "status": "connected"}
            if retained_profile is not None:
                connection_result.update(
                    retained_profile=retained_profile,
                    pending_records="preserved_in_original_profile_not_synced",
                )
            return connection_result
        if not interactive:
            # Legacy project selection requires human terminal input. Never
            # downgrade an agent-started browser flow to terminal credentials.
            raise AdapterError("browser_project_connect_required")

    result: dict[str, Any] | None = None
    try:
        with _native_login(
            transport, args.client if getattr(args, "browser_login", False) else None
        ) as token:
            new_source = False
            if manifest:
                project, source = manifest["project_id"], manifest["source_id"]
            else:
                workspaces = _items(
                    transport.request("/api/v1/workspaces", token=token, scheme="Bearer")
                )
                if not workspaces:
                    if not _yes("첫 연결입니다. 이 계정의 개인 작업 공간을 만들까요?"):
                        raise AdapterError("project_connection_cancelled")
                    transport.request(
                        "/api/v1/me/personal-space", token=token, scheme="Bearer", body={}
                    )
                    workspaces = _items(
                        transport.request("/api/v1/workspaces", token=token, scheme="Bearer")
                    )
                workspace = _choose(
                    "팀 선택",
                    workspaces,
                )
                selected = _choose(
                    "프로젝트 선택",
                    _items(
                        transport.request(
                            "/api/v1/workspaces/" + workspace["id"] + "/projects",
                            token=token,
                            scheme="Bearer",
                        )
                    ),
                )
                project = selected["id"]
                provider = {"codex": "openai", "claude": "anthropic"}[args.client]
                sources = _items(
                    transport.request(
                        "/api/v1/projects/" + project + "/sources", token=token, scheme="Bearer"
                    )
                )
                eligible = [
                    row
                    for row in sources
                    if row.get("active") is True
                    and row.get("routing_mode") == "cloud_preferred"
                    and isinstance(row.get("allowed_plugin_providers"), list)
                    and provider in row["allowed_plugin_providers"]
                ]
                if eligible:
                    source = _choose("작업 기록 출처 선택", eligible, "external_id")["id"]
                else:
                    print("이 프로젝트에 연결 가능한 작업 기록 출처가 없습니다.")
                    if not _yes(
                        "이 연결을 위한 새 두루마리 작업 출처를 만들까요? "
                        "기존 출처의 정책은 유지됩니다."
                    ):
                        raise AdapterError("project_connection_cancelled")
                    new_source = True
                    source = (
                        "pending-direct-source"  # Local preflight only, never sent as a binding.
                    )
            name = name or profile_for(project, args.client, root)
            if _existing(name):
                raise AdapterError("project_profile_exists_use_existing_binding")
            from durumari_mcp.project_outbox import state_root

            if (state_root() / name / "queue.enc").exists():
                raise AdapterError("profile_has_existing_outbox_use_new_name")
            # Validate host configuration before creating a durable server grant.
            init_project(
                root,
                origin,
                project,
                source,
                [args.client],
                apply=False,
                for_migration=getattr(args, "for_migration", False),
                preserve_disabled_hooks=True,
                profile_names={args.client: name},
            )
            capture = _yes("이 프로젝트에 작업 기록도 추가할까요?")
            actions = ["read", "capture"] if capture else ["read"]
            provider_name = "OpenAI" if args.client == "codex" else "Anthropic"
            print(f"선택한 프로젝트 맥락은 {provider_name}의 Agent 환경에 전달될 수 있습니다.")
            print("비밀값 사용·작업 실행·병합·배포 권한은 포함되지 않습니다.")
            if not getattr(args, "allow_external_context", False) and not _yes(
                "이 범위로 연결할까요?"
            ):
                raise AdapterError("project_connection_cancelled")
            if new_source:
                created = transport.request(
                    "/api/v1/projects/" + project + "/sources",
                    token=token,
                    scheme="Bearer",
                    body={
                        "provider": "direct",
                        "external_id": "durumari-" + args.client + "-" + uuid4().hex[:12],
                        "visibility": "restricted",
                    },
                )
                selected_source = created.get("id")
                revision = created.get("policy_revision")
                if (
                    not isinstance(selected_source, str)
                    or not re.fullmatch(r"[A-Za-z0-9-]{1,128}", selected_source)
                    or type(revision) is not int
                    or revision < 1
                ):
                    raise AdapterError("invalid_project_selection")
                source = selected_source
                transport.request(
                    "/api/v1/projects/" + project + "/sources/" + source + "/policy",
                    token=token,
                    scheme="Bearer",
                    method="PUT",
                    body={
                        "revision": revision,
                        "active": True,
                        "visibility": "restricted",
                        "routing_mode": "cloud_preferred",
                        "allowed_plugin_providers": [provider],
                    },
                )
            result = transport.request(
                "/api/v1/project-connections",
                token=token,
                scheme="Bearer",
                body={
                    "project_id": project,
                    "source_id": source,
                    "host": args.client,
                    "environment_name": args.client + "-" + root.name,
                    "actions": actions,
                    "external_consent": True,
                },
            )
            try:
                returned = ProjectConnection.model_validate(result["connection"])
            except Exception:
                raise AdapterError("invalid_project_connection") from None
            if (
                returned.project_id,
                returned.source_id,
                returned.host,
                sorted(returned.actions),
            ) != (project, source, args.client, sorted(actions)):
                raise AdapterError("project_connection_scope_changed")
        # Make host setup repeatable before exposing credentials to concurrent hooks.
        # If a file write fails, the new grant is revoked and no queue key is lost.
        init_project(
            root,
            origin,
            project,
            source,
            [args.client],
            apply=True,
            for_migration=getattr(args, "for_migration", False),
            preserve_disabled_hooks=True,
            profile_names={args.client: name},
        )
        configure_project(
            SimpleNamespace(
                profile=name,
                client=args.client,
                workspace=str(root),
                gateway_origin=origin,
                quiet=True,
            ),
            result,
        )
        from durumari_mcp.codex_host import connection_notice

        connection_notice(root, args.client)
        return {"profile": name, "status": "connected"}
    except BaseException:
        # Account-session cleanup and local setup can fail after server creation.
        # Do not leave an unconfigured grant active, or destroy a retained queue.
        if result is not None:
            try:
                transport.request(
                    "/api/v1/project-agent/logout",
                    token=SecretStr(result["access_token"]),
                    method="POST",
                )
            except Exception:
                raise AdapterError("project_bootstrap_cleanup_not_confirmed") from None
        raise
