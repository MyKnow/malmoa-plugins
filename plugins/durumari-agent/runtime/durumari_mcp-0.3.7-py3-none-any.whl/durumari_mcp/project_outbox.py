"""Authenticated encrypted outbox, atomic writes and cross-process locking."""

import json
import os
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any
from uuid import uuid4

from cryptography.fernet import Fernet, InvalidToken

from durumari_mcp.credentials import AdapterError, profile_name
from durumari_mcp.legacy import data_directory
from durumari_mcp.project_credentials import ProjectProfile

MAX_QUEUE_BYTES = 8_000_000
MAX_PENDING_EVENTS = 1000


def state_root() -> Path:
    # Only encrypted state is stored here; keys and credentials remain in OS storage.
    return data_directory(Path.home()) / "project-sync"


def protected_directory(path: Path) -> None:
    for parent in [*reversed(path.parents), path]:
        if parent.is_symlink():
            raise AdapterError("unsafe_outbox_path")
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not path.is_dir():
        raise AdapterError("unsafe_outbox_path")
    if os.name != "nt":
        path.chmod(0o700)


@contextmanager
def process_lock(directory: Path, *, timeout: float = 5) -> Iterator[None]:
    protected_directory(directory)
    lock = directory / "process.lock"
    if lock.is_symlink():
        raise AdapterError("unsafe_outbox_path")
    flags = os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(lock, flags, 0o600)
    deadline = time.monotonic() + timeout
    acquired = False
    try:
        if os.name == "nt":
            import msvcrt

            windows_lock: Any = msvcrt

            if os.fstat(fd).st_size == 0:
                os.write(fd, b"0")
            while True:
                try:
                    os.lseek(fd, 0, os.SEEK_SET)
                    windows_lock.locking(fd, windows_lock.LK_NBLCK, 1)
                    acquired = True
                    break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise AdapterError("project_profile_busy") from None
                    time.sleep(0.02)
        else:
            import fcntl

            while True:
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    acquired = True
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        raise AdapterError("project_profile_busy") from None
                    time.sleep(0.02)
        yield
    finally:
        if acquired:
            if os.name == "nt":
                os.lseek(fd, 0, os.SEEK_SET)
                windows_lock.locking(fd, windows_lock.LK_UNLCK, 1)
            else:
                fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


class Outbox:
    def __init__(self, root: Path, name: str, profile: ProjectProfile) -> None:
        self.directory = root / profile_name(name)
        self.path = self.directory / "queue.enc"
        self.cipher = Fernet(profile.outbox_key.get_secret_value().encode("ascii"))
        self.scope = {
            "connection_id": profile.connection_id,
            "project_id": profile.project_id,
            "source_id": profile.source_id,
            "actor_id": profile.actor_id,
            "client": profile.client,
            "workspace": profile.workspace,
        }

    def read(self) -> dict[str, Any]:
        if not self.path.exists():
            return {
                "version": 1,
                "scope": self.scope,
                "pending": [],
                "sessions": {},
                "last_ack": None,
                "status": "empty",
            }
        if self.path.is_symlink() or self.path.stat().st_size > MAX_QUEUE_BYTES * 2:
            raise AdapterError("protected_outbox_invalid")
        try:
            value = json.loads(self.cipher.decrypt(self.path.read_bytes()))
            if not isinstance(value, dict) or value.get("version") != 1:
                raise AdapterError("protected_outbox_invalid")
            if value.get("scope") != self.scope:
                raise AdapterError("outbox_scope_mismatch")
            if not isinstance(value.get("pending"), list) or not isinstance(
                value.get("sessions"), dict
            ):
                raise AdapterError("protected_outbox_invalid")
            return value
        except (InvalidToken, ValueError, OSError):
            raise AdapterError("protected_outbox_invalid") from None

    def write(self, state: dict[str, Any]) -> None:
        data = json.dumps(state, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        if len(data) > MAX_QUEUE_BYTES or len(state["pending"]) > MAX_PENDING_EVENTS:
            raise AdapterError("outbox_capacity_exceeded")
        encrypted = self.cipher.encrypt(data)
        temporary = self.directory / ("queue." + uuid4().hex + ".tmp")
        fd = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(encrypted)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            if os.name != "nt":
                directory_fd = os.open(self.directory, os.O_RDONLY)
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
        finally:
            temporary.unlink(missing_ok=True)

    @contextmanager
    def transaction(self) -> Iterator[dict[str, Any]]:
        # A lifecycle delivery holds this queue while sending its bounded batch.
        # Parallel host hooks must wait through that batch rather than abort an
        # otherwise valid Context tool call after the short credential-lock wait.
        with process_lock(self.directory, timeout=35):
            state = self.read()
            yield state
            self.write(state)
