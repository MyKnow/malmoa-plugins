"""Small, non-secret retry/notice state; never changes hook trust or capture queues."""

import hashlib
import json
import math
import os
import time
from pathlib import Path
from typing import Any
from uuid import uuid4

from durumari_mcp.credentials import AdapterError, profile_name
from durumari_mcp.project_outbox import process_lock, state_root

RETRY_SECONDS = 30
NOTICE_SECONDS = 300
HUMAN_ACTION_ERRORS = {
    "project_repository_mismatch_reconnect",
    "project_connection_scope_changed",
    "project_manifest_profile_mismatch",
    "workspace_out_of_scope",
}
RECOVERABLE = {
    "project_credential_missing",
    "project_login_required",
    "project_access_denied",
    "project_connection_unavailable",
    "project_action_denied",
    "project_delivery_unknown",
    "project_unavailable",
    "project_rate_limited",
    "project_profile_busy",
    "protected_project_store_read_failed",
    "protected_project_store_write_failed",
} | HUMAN_ACTION_ERRORS
NETWORK_ERRORS = {
    "project_delivery_unknown",
    "project_unavailable",
    "project_rate_limited",
    "project_profile_busy",
}


def recovery_root() -> Path:
    # Public health metadata is separate from the encrypted project-sync store.
    return state_root().parent / "hook-health"


class HookRecovery:
    def __init__(self, name: str, client: str, cwd: str) -> None:
        self.directory = recovery_root() / profile_name(name)
        scope = client + "\0" + str(Path(cwd).resolve())
        self.path = self.directory / (hashlib.sha256(scope.encode()).hexdigest() + ".json")

    def _read(self) -> dict[str, Any] | None:
        if not self.path.exists():
            return None
        if self.path.is_symlink() or self.path.stat().st_size > 1024:
            return None
        value = json.loads(self.path.read_text())
        if not isinstance(value, dict) or set(value) != {
            "reason",
            "failed_at",
            "notice_at",
            "notice_session",
        }:
            return None
        if value["reason"] not in RECOVERABLE or not isinstance(value["notice_session"], str):
            return None
        if any(
            type(value[key]) not in {int, float} or not math.isfinite(value[key])
            for key in ("failed_at", "notice_at")
        ):
            return None
        return value

    def status(self) -> dict[str, Any] | None:
        try:
            with process_lock(self.directory, timeout=0.05):
                return self._read()
        except (AdapterError, OSError, ValueError, TypeError):
            return None

    def cooling_down(self, status: dict[str, Any]) -> bool:
        return bool(0 <= time.time() - status["failed_at"] < RETRY_SECONDS)

    def defer(self, reason: str, session: str, *, cached: bool = False) -> bool:
        """Return whether to show a notice. Cached checks do not extend backoff."""
        now = time.time()
        session_key = hashlib.sha256(session.encode()).hexdigest()
        try:
            with process_lock(self.directory, timeout=0.05):
                previous = self._read()
                notify = not (
                    previous
                    and previous["reason"] == reason
                    and previous["notice_session"] == session_key
                    and (
                        reason in HUMAN_ACTION_ERRORS
                        or 0 <= now - previous["notice_at"] < NOTICE_SECONDS
                    )
                )
                value = {
                    "reason": reason,
                    "failed_at": previous["failed_at"] if cached and previous else now,
                    "notice_at": previous["notice_at"] if previous and not notify else now,
                    "notice_session": session_key,
                }
                temporary = self.directory / (uuid4().hex + ".tmp")
                try:
                    fd = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                    with os.fdopen(fd, "w") as stream:
                        json.dump(value, stream)
                    os.replace(temporary, self.path)
                finally:
                    temporary.unlink(missing_ok=True)
                return notify
        except (AdapterError, OSError, ValueError, TypeError):
            return True  # Failure to keep advisory state must not prevent recovery.

    def clear(self) -> None:
        try:
            with process_lock(self.directory, timeout=0.05):
                self.path.unlink(missing_ok=True)
        except (AdapterError, OSError):
            pass


def clear_hook_recovery(name: str) -> None:
    """New credentials permit an immediate retry; existing queues stay untouched."""
    directory = recovery_root() / profile_name(name)
    if not directory.exists():
        return
    try:
        with process_lock(directory, timeout=0.05):
            for path in directory.glob("*.json"):
                if not path.is_symlink():
                    path.unlink(missing_ok=True)
    except (AdapterError, OSError):
        pass
