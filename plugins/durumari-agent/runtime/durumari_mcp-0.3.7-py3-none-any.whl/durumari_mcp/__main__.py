from durumari_mcp.cli import main

main()
