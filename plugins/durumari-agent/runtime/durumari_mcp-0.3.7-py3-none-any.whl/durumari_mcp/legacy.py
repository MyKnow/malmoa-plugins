"""Compatibility boundaries for user-owned installations made before the rename.

Old credentials never change server or project scope. Pending encrypted records
keep using their existing lock and directory; they are never silently copied.
"""

import json
import re
import shlex
import subprocess
import tomllib
from pathlib import Path
from typing import Any

PLUGIN_SERVICE_V1 = "MALMOA.MCP.PluginCredential.v1"
PROJECT_SERVICE_V1 = "MALMOA.MCP.ProjectConnection.v1"
MANIFEST_V1 = "malmoa.yaml"
DIRECTORY_V1 = ".malmoa"
MODULE_V1 = "malmoa_mcp"
MCP_KEY_V1 = "malmoa_project"
MANAGED_START_V1 = "<!-- MALMOA MANAGED BEGIN -->"
MANAGED_END_V1 = "<!-- MALMOA MANAGED END -->"


def compatible_path(root: Path, current: str, previous: str) -> Path:
    from durumari_mcp.credentials import AdapterError

    latest, old = root / current, root / previous
    if latest.is_symlink() or old.is_symlink():
        raise AdapterError("unsafe_legacy_path")
    if latest.exists() and old.exists():
        raise AdapterError("ambiguous_legacy_state_requires_review")
    return old if old.exists() else latest


def manifest_path(root: Path) -> Path:
    return compatible_path(root, "durumari.yaml", MANIFEST_V1)


def data_directory(root: Path) -> Path:
    return compatible_path(root, ".durumari", DIRECTORY_V1)


def binding(servers: dict[str, Any]) -> dict[str, Any] | None:
    from durumari_mcp.credentials import AdapterError

    if "durumari_project" in servers and MCP_KEY_V1 in servers:
        raise AdapterError("ambiguous_legacy_binding_requires_review")
    return servers.get("durumari_project", servers.get(MCP_KEY_V1))


def canonical_binding(
    text: str, client: str, profile: str, python: str, *, previous_profile: str | None = None
) -> str:
    """Replace only our exact seven-argument scoped binding; preserve unrelated hosts."""
    from durumari_mcp.credentials import AdapterError

    data = tomllib.loads(text) if client == "codex" else json.loads(text or "{}")
    servers = data.get("mcp_servers" if client == "codex" else "mcpServers", {})
    existing = binding(servers)
    if existing is None:
        return text
    canonical = ["-m", "durumari_mcp", "project-serve", "--profile", profile, "--client", client]
    old = ["-m", MODULE_V1, *canonical[2:]]
    permitted = [canonical, old]
    if previous_profile is not None:
        for arguments in (canonical, old):
            permitted.append([*arguments[:4], previous_profile, *arguments[5:]])
    if existing.get("args") not in permitted:
        raise AdapterError("existing_mcp_binding_conflict")
    key = "durumari_project" if "durumari_project" in servers else MCP_KEY_V1
    if client == "claude":
        if set(existing) - {"type", "command", "args"}:
            raise AdapterError("existing_mcp_binding_conflict")
        del servers[key]
        servers["durumari_project"] = {"type": "stdio", "command": python, "args": canonical}
        return json.dumps(data, ensure_ascii=False, indent=2)
    if set(existing) - {"command", "args", "startup_timeout_sec"}:
        raise AdapterError("existing_mcp_binding_conflict")
    block = "[mcp_servers.durumari_project]\ncommand = " + json.dumps(python)
    block += "\nargs = " + json.dumps(canonical) + "\nstartup_timeout_sec = 30\n"
    pattern = r"(?ms)^\[mcp_servers\." + re.escape(key) + r"\][^\n]*\n.*?(?=^\[|\Z)"
    result, count = re.subn(pattern, lambda _: block, text)
    if count != 1:
        raise AdapterError("existing_mcp_binding_conflict")
    return result


def canonical_hooks(
    current: dict[str, Any], client: str, profile: str, python: str,
    *, previous_profile: str | None = None,
) -> dict[str, Any]:
    result: dict[str, Any] = json.loads(json.dumps(current))
    old_args = ["-m", MODULE_V1, "project-hook", "--profile", profile, "--client", client]
    new_args = ["-m", "durumari_mcp", *old_args[2:]]
    permitted = [old_args, new_args]
    if previous_profile is not None:
        for arguments in (old_args, new_args):
            permitted.append([*arguments[:4], previous_profile, *arguments[5:]])
    for groups in result.get("hooks", {}).values():
        for group in groups:
            for hook in group.get("hooks", []):
                if client == "claude" and hook.get("args") in permitted:
                    hook["command"], hook["args"] = python, new_args
                elif client == "codex":
                    try:
                        command = shlex.split(hook.get("command", ""))
                    except ValueError:
                        continue
                    if len(command) == 8 and command[1:] in permitted:
                        hook["command"] = shlex.join([python, *new_args])
                        if "commandWindows" in hook:
                            hook["commandWindows"] = subprocess.list2cmdline([python, *new_args])
    return result


def tool_pattern(pattern: str) -> str:
    """Keep earlier transcript tool names inside the same privacy checks."""
    return pattern.replace("durumari_", "(?:durumari|malmoa)_")
