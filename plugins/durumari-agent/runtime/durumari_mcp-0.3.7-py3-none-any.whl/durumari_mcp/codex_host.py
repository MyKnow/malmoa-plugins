"""Inspect Codex effective configuration; trust requires explicit user consent."""

import json
import os
import queue
import shutil
import subprocess
import threading
import tomllib
from pathlib import Path
from typing import Any

from durumari_mcp.credentials import AdapterError


def inspect_host(root: Path) -> dict[str, Any]:
    executable = shutil.which("codex")
    if not executable:
        return {"state": "unverified", "reason": "codex_cli_unavailable"}
    process = None
    try:
        process = subprocess.Popen(
            [executable, "app-server", "--stdio"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        stdin, stdout = process.stdin, process.stdout
        if stdin is None or stdout is None:
            raise OSError("Codex configuration streams unavailable")
        messages: queue.Queue[dict[str, Any]] = queue.Queue()

        def read() -> None:
            for line in stdout:
                try:
                    messages.put(json.loads(line))
                except ValueError:
                    pass

        threading.Thread(target=read, daemon=True).start()

        def request(identifier: int, method: str, params: dict[str, Any]) -> dict[str, Any]:
            stdin.write(
                json.dumps({"id": identifier, "method": method, "params": params}) + "\n"
            )
            stdin.flush()
            import time

            deadline = time.monotonic() + 10
            while True:
                result = messages.get(timeout=max(0.01, deadline - time.monotonic()))
                if result.get("id") == identifier:
                    value = result.get("result", {})
                    if not isinstance(value, dict):
                        raise ValueError("Invalid Codex configuration result")
                    return value
                if time.monotonic() >= deadline:
                    raise queue.Empty

        request(
            1,
            "initialize",
            {
                "clientInfo": {"name": "durumari-host-check", "version": "1"},
                "capabilities": {"experimentalApi": True},
            },
        )
        result = request(2, "config/read", {"cwd": str(root.resolve()), "includeLayers": True})
        for layer in result.get("layers", []):
            if layer.get("name", {}).get("dotCodexFolder") == str(root.resolve() / ".codex"):
                if layer.get("disabledReason"):
                    return {"state": "blocked", "reason": "codex_project_trust_required"}
                if "durumari_project" in result.get("config", {}).get("mcp_servers", {}):
                    return {
                        "state": "configured",
                        "reason": "host_reload_and_capture_verification_required",
                    }
        return {"state": "unverified", "reason": "codex_project_config_not_loaded"}
    except (OSError, ValueError, queue.Empty):
        return {"state": "unverified", "reason": "codex_config_inspection_failed"}
    finally:
        if process is not None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()


def trust_workspace(root: Path) -> None:
    """Called only with --trust-workspace after explicit human authorization."""
    path = Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))) / "config.toml"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise AdapterError("codex_trust_config_unsafe")
    # Append only; preserve user settings and existing explicit distrust.
    with path.open("a+", encoding="utf-8") as handle:
        handle.seek(0)
        original = handle.read()
        try:
            config = tomllib.loads(original)
        except ValueError:
            raise AdapterError("codex_trust_config_invalid") from None
        key = str(root.resolve())
        existing = config.get("projects", {}).get(key)
        if existing is not None:
            if existing.get("trust_level") == "trusted":
                return
            raise AdapterError("codex_project_explicitly_untrusted")
        addition = (
            "\n[projects." + json.dumps(key, ensure_ascii=False) + ']\ntrust_level = "trusted"\n'
        )
        tomllib.loads(original + addition)
        handle.write(addition)
        handle.flush()
        os.fsync(handle.fileno())


def connection_notice(root: Path, client: str) -> dict[str, Any]:
    result = (
        inspect_host(root)
        if client == "codex"
        else {"state": "unverified", "reason": "host_approval_required"}
    )
    if result["reason"] == "codex_project_trust_required":
        print("서버 연결은 완료됐지만 Codex가 이 폴더의 MCP·훅 설정을 비활성화했습니다.")
        print(
            "현재 폴더의 로컬 코드 실행 신뢰에 명시적으로 동의한 경우에만 "
            "connect --trust-workspace로 등록하세요."
        )
    else:
        print("서버 연결 완료. 호스트 설정 상태: " + result["reason"])
    return result
