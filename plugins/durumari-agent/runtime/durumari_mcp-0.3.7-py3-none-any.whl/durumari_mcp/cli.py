"""Interactive credential provisioning is separate from the MCP protocol process."""

import argparse
import getpass
import json
import logging
import os
import shlex
import sys
from importlib.metadata import version
from typing import Any, Never

from pydantic import SecretStr

from durumari_mcp.credentials import (
    AdapterError,
    Profile,
    delete_profile,
    load_profile,
    save_profile,
)
from durumari_mcp.gateway import Gateway
from durumari_mcp.server import Adapter, create_server


class Parser(argparse.ArgumentParser):
    def error(self, message: str) -> Never:
        # An accidentally pasted credential must not be echoed by argparse.
        raise AdapterError("invalid_command_arguments")


def stdin_line(max_bytes: int) -> bytes:
    # No buffered read-ahead: a protocol message may follow a bootstrap frame
    # in the same pipe write. The SDK must receive every remaining byte.
    data = bytearray()
    while len(data) <= max_bytes:
        byte = os.read(0, 1)
        if byte == b"\n":
            return bytes(data).rstrip(b"\r")
        if not byte:
            raise AdapterError("bootstrap_input_incomplete")
        data.extend(byte)
    raise AdapterError("bootstrap_input_too_large")


def bootstrap_profile() -> Profile:
    try:
        frame = json.loads(stdin_line(8192))
        if (
            set(frame) != {"jsonrpc", "method", "params"}
            or frame["jsonrpc"] != "2.0"
            or frame["method"] != "durumari/bootstrap"
        ):
            raise AdapterError("invalid_bootstrap_frame")
        return Profile.model_validate(frame["params"])
    except AdapterError:
        raise
    except Exception:
        raise AdapterError("invalid_bootstrap_frame") from None


def build_parser() -> Parser:
    parser = Parser(prog="durumari-mcp")
    parser.add_argument("--version", action="version", version=version("durumari-mcp"))
    subcommands = parser.add_subparsers(dest="command", required=True, parser_class=Parser)
    configure = subcommands.add_parser("configure", help="Store a short Plugin credential securely")
    configure.add_argument("--profile", required=True)
    configure.add_argument("--gateway-origin", required=True)
    configure.add_argument("--client", choices=["codex", "claude"], required=True)
    configure.add_argument(
        "--destination", choices=["codex-model", "claude-model", "local-tool"], required=True
    )
    configure.add_argument("--stdin", action="store_true", help="Read credential line from a pipe")
    serve = subcommands.add_parser("serve", help="Run the MCP stdio server")
    serve.add_argument("--profile", required=True)
    serve.add_argument("--client", choices=["codex", "claude"], required=True)
    ephemeral = subcommands.add_parser("serve-stdin", help="Use one in-memory bootstrap frame")
    ephemeral.add_argument("--client", choices=["codex", "claude"], required=True)
    forget = subcommands.add_parser("forget", help="Remove a locally stored credential")
    forget.add_argument("--profile", required=True)
    connect = subcommands.add_parser("project-connect", help="Guided project login and recovery")
    connect.add_argument("--workspace", default=os.getcwd())
    connect.add_argument("--client", choices=["codex", "claude"], required=True)
    connect.add_argument("--gateway-origin")
    connect.add_argument("--reauth", action="store_true")
    connect.add_argument("--browser-login", action="store_true")
    connect.add_argument("--allow-external-context", action="store_true")
    connect.add_argument("--for-migration", action="store_true")
    connect.add_argument("--create-workspace", action="store_true")
    connect.add_argument("--requested-project")
    connect.add_argument(
        "--trust-workspace",
        action="store_true",
        help="Register this exact Codex workspace after explicit human consent",
    )
    for command in [
        "project-login",
        "project-configure",
        "project-serve",
        "project-hook",
        "project-sync",
        "project-status",
        "project-logout",
        "project-forget",
    ]:
        project = subcommands.add_parser(command, help="Scoped project continuity operation")
        project.add_argument("--profile", required=True)
        project.add_argument("--client", choices=["codex", "claude"], required=True)
        if command in {"project-login", "project-configure"}:
            project.add_argument("--gateway-origin", required=True)
            project.add_argument("--workspace", required=True)
        if command == "project-login":
            project.add_argument("--project-id", required=True)
            project.add_argument("--source-id", required=True)
            project.add_argument("--environment-name", required=True)
            project.add_argument("--allow-external-context", action="store_true")
        if command == "project-configure":
            project.add_argument("--stdin", action="store_true")
        if command in {"project-logout", "project-forget"}:
            project.add_argument("--discard-pending", action="store_true")
    for name in ("release-install", "update"):
        release = subcommands.add_parser(name, help="Install or update the public native plugin")
        release.add_argument("--server")
        release.add_argument("--client", choices=["codex", "claude", "both"])
        release.add_argument("--check", action="store_true")
        release.add_argument("--status", action="store_true")
        release.add_argument(
            "--debug",
            action="store_true",
            help=(
                "Include host output in the local failure report; "
                "review for secrets before sharing."
            ),
        )
    from durumari_mcp.onboarding_cli import add_commands

    add_commands(subcommands)
    return parser


def execute(args: Any) -> None:
    if args.command == "project-connect":
        from durumari_mcp.connect_cli import connect_project

        connect_project(args)
        return
    if args.command in {"release-install", "update"}:
        from durumari_mcp.releases import ReleaseError, execute_cli_release

        try:
            print(json.dumps(execute_cli_release(args)))
        except ReleaseError as error:
            if error.diagnostic_path:
                print(json.dumps({"diagnostic_path": error.diagnostic_path}), file=sys.stderr)
            raise AdapterError(str(error)) from None
        return
    if args.command in {
        "project-init", "project-import", "project-export", "project-doctor", "project-preflight"
    }:
        from durumari_mcp.onboarding_cli import execute_onboarding

        execute_onboarding(args)
        return
    if args.command.startswith("project-"):
        from durumari_mcp.project_cli import execute_project

        execute_project(args, stdin_line)
        return
    if args.command == "forget":
        delete_profile(args.profile)
        print(
            "Durumari credential removed locally; revoke the connection in Durumari too.",
            file=sys.stderr,
        )
        return
    if args.command == "configure":
        if args.stdin:
            token = stdin_line(200).decode("ascii")
        else:
            if not sys.stdin.isatty():
                raise AdapterError("use_explicit_stdin_bootstrap")
            token = getpass.getpass("Short Durumari Plugin credential: ")
        profile = Profile(
            gateway_origin=args.gateway_origin,
            plugin_token=SecretStr(token),
            client=args.client,
            destination_id=args.destination,
        )
        profile.check_client(args.client)
        Adapter(Gateway(profile))  # Verify scope before storing. Never forwards native tokens.
        save_profile(args.profile, profile)
        print("Durumari Plugin credential stored in the OS credential store.", file=sys.stderr)
        return
    profile = bootstrap_profile() if args.command == "serve-stdin" else load_profile(args.profile)
    profile.check_client(args.client)
    create_server(Adapter(Gateway(profile))).run(transport="stdio")


def main() -> None:
    # No dependency debug logging or input/response exception tracebacks.
    logging.disable(logging.CRITICAL)
    args: Any = None
    try:
        args = build_parser().parse_args()
        execute(args)
    except AdapterError as error:
        print("두루마리: " + str(error), file=sys.stderr)
        if str(error) in {
            "project_login_required",
            "interactive_project_login_required",
            "project_profile_exists_use_new_name",
            "profile_has_existing_outbox_use_new_name",
        }:
            command = ["durumari-mcp", "project-connect"]
            client = getattr(args, "client", None)
            if client in {"codex", "claude"}:
                command += ["--client", client]
            workspace = getattr(args, "workspace", None)
            if not workspace and getattr(args, "profile", None):
                try:
                    from durumari_mcp.project_credentials import load_project_profile

                    workspace = load_project_profile(args.profile).workspace
                except AdapterError:
                    pass
            if workspace:
                command += ["--workspace", workspace]
            print(
                "기존 작업 기록을 보존하는 연결 안내를 사용자 터미널에서 실행해 주세요:",
                file=sys.stderr,
            )
            print(shlex.join(command), file=sys.stderr)
        elif str(error) == "project_connection_cancelled":
            print("연결을 취소했습니다. 기존 기록은 유지됩니다.", file=sys.stderr)
        elif str(error) == "project_selection_unavailable":
            print("접근 가능한 팀·프로젝트·출처를 먼저 준비해 주세요.", file=sys.stderr)
        elif str(error) in {"project_delivery_unknown", "project_unavailable"}:
            print(
                "서버 연결을 확인해 주세요. 기존 로그인 정보와 기록은 보존됩니다.", file=sys.stderr
            )
        elif str(error) in {"project_access_denied", "project_connection_unavailable"}:
            print(
                "로그인 정보와 프로젝트 접근 권한을 확인해 주세요. 회수되거나 만료된 "
                "연결은 복구할 수 없습니다. 기존 기록은 보존됩니다.",
                file=sys.stderr,
            )
        elif str(error) in {
            "protected_project_store_write_failed",
            "protected_project_store_read_failed",
        }:
            print(
                "OS 보안 저장소의 접근 승인을 확인한 뒤 다시 연결해 주세요. "
                "기존 기록은 보존됩니다.",
                file=sys.stderr,
            )
        elif str(error) in {"workspace_directory_required", "workspace_create_failed"}:
            print(
                "작업 폴더를 확인하거나 --create-workspace로 새 폴더를 만들어 연결하세요.",
                file=sys.stderr,
            )
        elif str(error) == "workspace_text_invalid_utf8":
            print(
                "프로젝트 설정 파일을 UTF-8로 저장한 뒤 다시 연결하세요. 기존 파일은 보존됩니다.",
                file=sys.stderr,
            )
        elif str(error) == "invalid_server_setup_files":
            print(
                "서버 연결 파일의 프로젝트·출처·무결성을 확인하지 못했습니다. 다시 연결하세요.",
                file=sys.stderr,
            )
        raise SystemExit(2) from None
    except (KeyboardInterrupt, BrokenPipeError):
        raise SystemExit(0) from None
    except UnicodeError:
        print("두루마리: workspace_text_invalid_utf8", file=sys.stderr)
        print(
            "프로젝트 설정 파일을 UTF-8로 저장한 뒤 다시 연결하세요. 기존 파일은 보존됩니다.",
            file=sys.stderr,
        )
        raise SystemExit(2) from None
    except Exception:
        print("두루마리: operation_failed", file=sys.stderr)
        raise SystemExit(2) from None


if __name__ == "__main__":
    main()
